import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import path from "node:path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { seedDemoData } from "../seed";

function isPortAvailable(port: number): Promise<boolean> { return new Promise(resolve => { const s = net.createServer(); s.listen(port, () => s.close(() => resolve(true))); s.on("error", () => resolve(false)); }); }
async function findAvailablePort(start=3000) { for (let p=start; p<start+20; p++) if (await isPortAvailable(p)) return p; throw new Error("No available port"); }
async function startServer() {
  const app=express(); const server=createServer(app);
  app.use(express.json({limit:"50mb"})); app.use(express.urlencoded({limit:"50mb", extended:true}));
  const uploadDir=path.resolve(process.env.UPLOAD_DIR ?? "uploads");
  app.use("/uploads", express.static(uploadDir));
  seedDemoData().catch(err => console.error("[Seed] Error:", err));
  app.use("/api/trpc", createExpressMiddleware({router: appRouter, createContext}));
  if (process.env.NODE_ENV === "development") await setupVite(app, server); else serveStatic(app);
  const preferred=parseInt(process.env.PORT || "3000"); const port=await findAvailablePort(preferred);
  server.listen(port, () => console.log(`Standalone server running on http://localhost:${port}/`));
}
startServer().catch(console.error);
