import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { verifyStaffToken, type StaffSessionPayload } from "../staffAuth";
import cookie from "cookie";

export const STAFF_COOKIE_NAME = "sallaq_staff_session";
export type TrpcContext = { req: CreateExpressContextOptions["req"]; res: CreateExpressContextOptions["res"]; user: User | null; staff: StaffSessionPayload | null };

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let staff: StaffSessionPayload | null = null;
  try {
    const rawCookies = opts.req.headers.cookie;
    if (rawCookies) {
      const token = cookie.parse(rawCookies)[STAFF_COOKIE_NAME];
      if (token) staff = await verifyStaffToken(token);
    }
  } catch { staff = null; }
  return { req: opts.req, res: opts.res, user: null, staff };
}
