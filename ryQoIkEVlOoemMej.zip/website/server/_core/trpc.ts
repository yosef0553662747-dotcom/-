import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

export const protectedProcedure = t.procedure.use(({ ctx, next }) => {
  if (!ctx.staff) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Please login to proceed",
    });
  }
  return next({
    ctx: {
      ...ctx,
      staff: ctx.staff,
    },
  });
});

export const adminProcedure = t.procedure.use(({ ctx, next }) => {
  const isStaffAdmin = ctx.staff?.role === "admin";

  if (!isStaffAdmin) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Admin privileges required",
    });
  }

  return next({
    ctx: {
      ...ctx,
      staff: ctx.staff,
    },
  });
});

export const developerProcedure = t.procedure.use(({ ctx, next }) => {
  const allowed = ctx.staff?.role === "developer" || ctx.staff?.role === "admin";
  if (!allowed) throw new TRPCError({ code: "FORBIDDEN", message: "Developer privileges required" });
  return next({ ctx: { ...ctx, staff: ctx.staff } });
});
