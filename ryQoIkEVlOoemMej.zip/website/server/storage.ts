import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

const root = path.resolve(process.env.UPLOAD_DIR ?? "uploads");
function safeName(key:string) { return key.replace(/\\/g,"/").split("/").filter(Boolean).map(part=>part.replace(/[^a-zA-Z0-9._-]/g,"_")).join("/"); }
export async function storagePut(relKey:string, data:Buffer|Uint8Array|string, contentType="application/octet-stream") {
  const original=safeName(relKey); const ext=path.extname(original); const base=original.slice(0, original.length-ext.length);
  const key=`${base}_${crypto.randomUUID().replace(/-/g,"").slice(0,8)}${ext}`; const target=path.join(root,key);
  await fs.mkdir(path.dirname(target), {recursive:true}); await fs.writeFile(target, data);
  return {key, url:`/uploads/${key}`};
}
export async function storageGet(relKey:string) { const key=safeName(relKey); return {key,url:`/uploads/${key}`}; }
export async function storageGetSignedUrl(relKey:string) { return `/uploads/${safeName(relKey)}`; }
