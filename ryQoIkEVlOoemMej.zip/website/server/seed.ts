import { hashPassword } from "./staffAuth";
import * as db from "./db";

export async function seedDemoData() {
  const database = await db.getDb();
  if (!database) return;

  const existingStaff = await db.getAllStaff();
  if (existingStaff.length === 0) {
    console.log("Seeding initial staff accounts...");
    // 1 Admin account
    const adminPass = hashPassword("admin123");
    await db.createStaffAccount({
      username: "admin",
      passwordHash: adminPass,
      fullName: "مشعل (المدير العام)",
      role: "admin",
      preferredLanguage: "ar",
      phone: "0501234567",
      isActive: 1,
    });

    // 2 Worker accounts (e.g. Arabic speaker and Bengali speaker)
    const worker1Pass = hashPassword("worker123");
    const worker1Id = await db.createStaffAccount({
      username: "salim",
      passwordHash: worker1Pass,
      fullName: "سالم المري (كاشير)",
      role: "worker",
      preferredLanguage: "ar",
      phone: "0559876543",
      isActive: 1,
    });

    const worker2Pass = hashPassword("worker123");
    const worker2Id = await db.createStaffAccount({
      username: "rahim",
      passwordHash: worker2Pass,
      fullName: "رحيم الإسلام (রফিক/ক্যাশিয়ার)",
      role: "worker",
      preferredLanguage: "bn",
      phone: "0543219876",
      isActive: 1,
    });

    console.log("Seeding initial products with images...");
    const p1 = await db.createProduct({
      sku: "RICE-BAS-01",
      barcode: "62810010001",
      nameAr: "أرز بسمتي هندي فاخر 5 كجم",
      nameEn: "Basmati Rice 5kg Premium",
      nameBn: "বাসমতি চাল ৫ কেজি",
      category: "مواد غذائية",
      imageUrl: "/uploads/rice_f13e01a0.png",
      costPrice: "32.00",
      sellingPrice: "45.00",
      taxRate: "15.00",
      stockQuantity: 38,
      minStockAlert: 10,
      maxStockAlert: 60,
      unit: "كيس",
    });

    const p2 = await db.createProduct({
      sku: "OIL-COOK-02",
      barcode: "62810010002",
      nameAr: "زيت نباتي للقلي والطبخ 1.5 لتر",
      nameEn: "Cooking Oil 1.5L",
      nameBn: "রান্নার তেল ১.৫ লিটার",
      category: "مواد غذائية",
      imageUrl: "/uploads/oil_1a68fc10.png",
      costPrice: "11.50",
      sellingPrice: "16.00",
      taxRate: "15.00",
      stockQuantity: 4, // low stock for alert testing
      minStockAlert: 8,
      maxStockAlert: 40,
      unit: "حبة",
    });

    const p3 = await db.createProduct({
      sku: "SUGAR-WH-03",
      barcode: "62810010003",
      nameAr: "سكر أبيض ناعم 2 كجم",
      nameEn: "White Sugar 2kg",
      nameBn: "সাদা চিনি ২ কেজি",
      category: "مواد غذائية",
      imageUrl: "/uploads/sugar_23935f8e.png",
      costPrice: "6.00",
      sellingPrice: "9.50",
      taxRate: "15.00",
      stockQuantity: 22,
      minStockAlert: 5,
      maxStockAlert: 50,
      unit: "كيس",
    });

    const p4 = await db.createProduct({
      sku: "TEA-BAG-04",
      barcode: "62810010004",
      nameAr: "شاي أسود فاخر 100 كيس",
      nameEn: "Black Tea 100 Bags",
      nameBn: "কালো চা ১০০ টি ব্যাগ",
      category: "مشروبات",
      imageUrl: "/uploads/tea_45161f23.png",
      costPrice: "10.00",
      sellingPrice: "15.00",
      taxRate: "15.00",
      stockQuantity: 18,
      minStockAlert: 5,
      maxStockAlert: 35,
      unit: "علبة",
    });

    const p5 = await db.createProduct({
      sku: "MILK-FR-05",
      barcode: "62810010005",
      nameAr: "حليب طازج كامل الدسم 1 لتر",
      nameEn: "Fresh Milk 1L",
      nameBn: "তাজা দুধ ১ লিটার",
      category: "ألبان",
      imageUrl: "/uploads/milk_f47fe4b2.png",
      costPrice: "4.50",
      sellingPrice: "6.50",
      taxRate: "15.00",
      stockQuantity: 15,
      minStockAlert: 5,
      maxStockAlert: 30,
      unit: "حبة",
    });

    console.log("Seeding sample sales for customer #55 and others...");
    // Completed sale 1: Customer #55 bought Rice & Oil
    await db.createSalesOrder(
      {
        orderNumber: "INV-100055",
        customerNumber: 55,
        customerName: "محمد الهاجري",
        customerPhone: "0505555555",
        sellerStaffId: worker1Id,
        subtotal: "77.00",
        totalTax: "11.55",
        totalCost: "55.00",
        grandTotal: "88.55",
        netProfit: "22.00",
        paymentMethod: "card",
        status: "completed",
        notes: "الزبون رقم 55 اشترى كيس أرز و2 زيت",
      },
      [
        {
          productId: p1,
          productName: "أرز بسمتي هندي فاخر 5 كجم",
          quantity: 1,
          unitCostPrice: "32.00",
          unitSellingPrice: "45.00",
          taxRate: "15.00",
          taxAmount: "6.75",
          lineTotal: "51.75",
          lineProfit: "13.00",
        },
        {
          productId: p2,
          productName: "زيت نباتي للقلي والطبخ 1.5 لتر",
          quantity: 2,
          unitCostPrice: "11.50",
          unitSellingPrice: "16.00",
          taxRate: "15.00",
          taxAmount: "4.80",
          lineTotal: "36.80",
          lineProfit: "9.00",
        },
      ]
    );

    // Sale 2: Worker 2 sold sugar and tea
    await db.createSalesOrder(
      {
        orderNumber: "INV-100056",
        customerNumber: 56,
        customerName: "خالد الحربي",
        customerPhone: "0566666666",
        sellerStaffId: worker2Id,
        subtotal: "34.00",
        totalTax: "5.10",
        totalCost: "22.00",
        grandTotal: "39.10",
        netProfit: "12.00",
        paymentMethod: "cash",
        status: "completed",
        notes: "دفع نقدي",
      },
      [
        {
          productId: p3,
          productName: "سكر أبيض ناعم 2 كجم",
          quantity: 2,
          unitCostPrice: "6.00",
          unitSellingPrice: "9.50",
          taxRate: "15.00",
          taxAmount: "2.85",
          lineTotal: "21.85",
          lineProfit: "7.00",
        },
        {
          productId: p4,
          productName: "شاي أسود فاخر 100 كيس",
          quantity: 1,
          unitCostPrice: "10.00",
          unitSellingPrice: "15.00",
          taxRate: "15.00",
          taxAmount: "2.25",
          lineTotal: "17.25",
          lineProfit: "5.00",
        },
      ]
    );

    // Cancelled sale for worker 1
    const cancelOrderId = await db.createSalesOrder(
      {
        orderNumber: "INV-100057",
        customerNumber: 57,
        customerName: "طارق السعيد",
        customerPhone: "0577777777",
        sellerStaffId: worker1Id,
        subtotal: "45.00",
        totalTax: "6.75",
        totalCost: "32.00",
        grandTotal: "51.75",
        netProfit: "13.00",
        paymentMethod: "cash",
        status: "cancelled",
        cancelReason: "الزبون غير رأيه قبل الاستلام",
        cancelledByStaffId: 1,
        notes: "تم إلغاء الطلب بناء على رغبة العميل",
      },
      [
        {
          productId: p1,
          productName: "أرز بسمتي هندي فاخر 5 كجم",
          quantity: 1,
          unitCostPrice: "32.00",
          unitSellingPrice: "45.00",
          taxRate: "15.00",
          taxAmount: "6.75",
          lineTotal: "51.75",
          lineProfit: "13.00",
        },
      ]
    );

    // Initial Stocktake Session
    const stkId = await db.createStocktakeSession({
      sessionCode: "STK-WEEK-01",
      title: "جرد بداية الأسبوع الشامل",
      cycleType: "weekly",
      status: "requested",
      requestedByStaffId: 1,
      notes: "يرجى من جميع العمال إكمال عد المنتجات في الرفوف والمستودع",
    });

    // Initial alert notification
    await db.createStaffNotification({
      senderStaffId: 1,
      titleAr: "سوو جرد الآن للمخزون الأسبوعي",
      titleEn: "Perform weekly inventory count now",
      titleBn: "এখনই সাপ্তাহিক পণ্য গণনা শুরু করুন",
      messageAr: "تنبيه من الإدارة: تم فتح جلسة جرد أسبوعي يرجى حصر كميات الأرز والزيت والسكر",
      messageEn: "Management notice: Weekly stocktake opened. Please record actual shelf counts.",
      messageBn: "ম্যানেজমেন্ট নোটিশ: সাপ্তাহিক পণ্য গণনা খোলা হয়েছে। বাস্তব সংখ্যা হিসাব করুন।",
      type: "stocktake_alert",
      referenceId: "STK-WEEK-01",
    });

    console.log("Demo seed finished successfully!");
  }
}
