import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, publicProcedure, protectedProcedure, adminProcedure, developerProcedure } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { STAFF_COOKIE_NAME } from "./_core/context";
import { getSessionCookieOptions } from "./_core/cookies";
import { hashPassword, verifyPassword, signStaffToken } from "./staffAuth";
import * as db from "./db";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,

  // Standalone local staff authentication
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (ctx.staff) {
        return {
          type: "staff" as const,
          staff: ctx.staff,
          role: ctx.staff.role,
        };
      }
            return null;
    }),

    loginStaff: publicProcedure
      .input(
        z.object({
          username: z.string().min(1),
          password: z.string().min(1),
          expectedRole: z.enum(["admin", "worker", "developer"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const staff = await db.getStaffByUsername(input.username.trim());
        if (!staff || !staff.isActive) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          });
        }

        const valid = verifyPassword(input.password, staff.passwordHash);
        if (!valid) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          });
        }

        if (input.expectedRole && staff.role !== input.expectedRole) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              input.expectedRole === "admin" ? "هذا الحساب ليس لديه صلاحية الإدارة" : input.expectedRole === "developer" ? "هذا الحساب ليس لديه صلاحية المطور" : "يرجى تسجيل الدخول من بوابة العمال",
          });
        }

        // update last login
        await db.updateStaffAccount(staff.id, { lastLoginAt: new Date() });

        const token = await signStaffToken({
          staffId: staff.id,
          username: staff.username,
          fullName: staff.fullName,
          role: staff.role,
          preferredLanguage: staff.preferredLanguage,
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(STAFF_COOKIE_NAME, token, {
          ...cookieOptions,
          maxAge: 30 * 24 * 60 * 60 * 1000,
        });

        return {
          success: true,
          staff: {
            id: staff.id,
            username: staff.username,
            fullName: staff.fullName,
            role: staff.role,
            preferredLanguage: staff.preferredLanguage,
          },
        };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(STAFF_COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),

    switchLanguage: protectedProcedure
      .input(z.object({ language: z.enum(["ar", "en", "bn"]) }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.staff) {
          await db.updateStaffAccount(ctx.staff.staffId, {
            preferredLanguage: input.language,
          });
          // re-issue token
          const token = await signStaffToken({
            ...ctx.staff,
            preferredLanguage: input.language,
          });
          const cookieOptions = getSessionCookieOptions(ctx.req);
          ctx.res.cookie(STAFF_COOKIE_NAME, token, {
            ...cookieOptions,
            maxAge: 30 * 24 * 60 * 60 * 1000,
          });
        }
        return { success: true, language: input.language };
      }),
  }),

  settings: router({
    public: publicProcedure.query(async () => db.getAppSettings()),
    get: developerProcedure.query(async () => db.getAppSettings()),
    update: developerProcedure
      .input(z.record(z.string(), z.string().max(200000)))
      .mutation(async ({ input, ctx }) => {
        await db.saveAppSettings(input, ctx.staff?.staffId);
        return { success: true };
      }),
    uploadAsset: developerProcedure
      .input(z.object({ filename: z.string(), contentType: z.string(), base64Data: z.string() }))
      .mutation(async ({ input }) => {
        if (!input.contentType.startsWith("image/") && !input.contentType.startsWith("video/")) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح برفع الصور والفيديو فقط" });
        }
        const buffer = Buffer.from(input.base64Data, "base64");
        const upload = await storagePut(`branding/${Date.now()}-${input.filename}`, buffer, input.contentType);
        return { url: upload.url };
    }),
  }),

  menuSections: router({
    list: protectedProcedure.query(async () => db.getMenuSections(false)),
    manage: developerProcedure.query(async () => db.getMenuSections(true)),
    create: developerProcedure
      .input(z.object({
        slug: z.string().min(2).max(80).regex(/^[a-z0-9-]+$/, "استخدم أحرفاً إنجليزية صغيرة وأرقاماً وشرطة فقط"),
        nameAr: z.string().min(1).max(120),
        nameEn: z.string().min(1).max(120),
        nameBn: z.string().min(1).max(120),
        imageUrl: z.string().optional(),
        displayOrder: z.number().int().default(0),
        isActive: z.number().int().min(0).max(1).default(1),
      }))
      .mutation(async ({ input }) => {
        try {
          const id = await db.createMenuSection({ ...input, imageUrl: input.imageUrl || null });
          return { success: true, id };
        } catch (error: any) {
          if (error?.code === "ER_DUP_ENTRY") throw new TRPCError({ code: "CONFLICT", message: "معرّف القسم مستخدم مسبقاً" });
          throw error;
        }
      }),
    update: developerProcedure
      .input(z.object({
        id: z.number(),
        slug: z.string().min(2).max(80).regex(/^[a-z0-9-]+$/).optional(),
        nameAr: z.string().min(1).max(120).optional(),
        nameEn: z.string().min(1).max(120).optional(),
        nameBn: z.string().min(1).max(120).optional(),
        imageUrl: z.string().optional(),
        displayOrder: z.number().int().optional(),
        isActive: z.number().int().min(0).max(1).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...patch } = input;
        await db.updateMenuSection(id, { ...patch, imageUrl: patch.imageUrl || null });
        return { success: true };
      }),
    delete: developerProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteMenuSection(input.id);
        return { success: true };
      }),
  }),

  // Staff Account Management (Admin only)
  staff: router({
    list: adminProcedure.query(async () => {
      const staffList = await db.getAllStaff();
      return staffList.map((s) => ({
        id: s.id,
        username: s.username,
        fullName: s.fullName,
        role: s.role,
        preferredLanguage: s.preferredLanguage,
        phone: s.phone,
        isActive: s.isActive,
        lastLoginAt: s.lastLoginAt,
        createdAt: s.createdAt,
      }));
    }),

    create: adminProcedure
      .input(
        z.object({
          username: z.string().min(2),
          password: z.string().min(4),
          fullName: z.string().min(2),
          role: z.enum(["admin", "worker", "developer"]),
          preferredLanguage: z.enum(["ar", "en", "bn"]).default("ar"),
          phone: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const existing = await db.getStaffByUsername(input.username.trim());
        if (existing) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "اسم المستخدم مسجل مسبقاً",
          });
        }

        const passwordHash = hashPassword(input.password);
        const id = await db.createStaffAccount({
          username: input.username.trim(),
          passwordHash,
          fullName: input.fullName.trim(),
          role: input.role,
          preferredLanguage: input.preferredLanguage,
          phone: input.phone?.trim() || null,
          isActive: 1,
        });

        return { success: true, id };
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          fullName: z.string().optional(),
          role: z.enum(["admin", "worker", "developer"]).optional(),
          preferredLanguage: z.enum(["ar", "en", "bn"]).optional(),
          phone: z.string().optional(),
          isActive: z.number().optional(),
          password: z.string().min(4).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const patch: Record<string, any> = {};
        if (input.fullName !== undefined) patch.fullName = input.fullName;
        if (input.role !== undefined) patch.role = input.role;
        if (input.preferredLanguage !== undefined) patch.preferredLanguage = input.preferredLanguage;
        if (input.phone !== undefined) patch.phone = input.phone;
        if (input.isActive !== undefined) patch.isActive = input.isActive;
        if (input.password) {
          patch.passwordHash = hashPassword(input.password);
        }

        await db.updateStaffAccount(input.id, patch);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.staff?.staffId === input.id) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن حذف حساب الإدارة المستخدم حالياً" });
        }
        const target = await db.getStaffById(input.id);
        if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "الحساب غير موجود" });
        await db.deleteStaffAccount(input.id);
        return { success: true };
      }),

    performance: adminProcedure.query(async () => {
      return db.getStaffPerformance();
    }),

    salesDetails: adminProcedure
      .input(z.object({ staffId: z.number() }))
      .query(async ({ input }) => db.getStaffSalesDetails(input.staffId)),
  }),

  // Products & Inventory Management
  products: router({
    list: protectedProcedure.query(async () => {
      return db.getAllProducts();
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const prod = await db.getProductById(input.id);
      if (!prod) throw new TRPCError({ code: "NOT_FOUND", message: "المنتج غير موجود" });
      return prod;
    }),

    create: adminProcedure
      .input(
        z.object({
          sku: z.string().min(1),
          barcode: z.string().optional(),
          nameAr: z.string().min(1),
          nameEn: z.string().min(1),
          nameBn: z.string().min(1),
          category: z.string().default("general"),
          imageUrl: z.string().optional(),
          costPrice: z.number().nonnegative(),
          sellingPrice: z.number().nonnegative(),
          taxRate: z.number().nonnegative().default(0),
          stockQuantity: z.number().int().default(0),
          minStockAlert: z.number().int().default(5),
          maxStockAlert: z.number().int().default(50),
          unit: z.string().default("pcs"),
        })
      )
      .mutation(async ({ input }) => {
        const id = await db.createProduct({
          sku: input.sku.trim(),
          barcode: input.barcode?.trim() || null,
          nameAr: input.nameAr.trim(),
          nameEn: input.nameEn.trim(),
          nameBn: input.nameBn.trim(),
          category: input.category.trim(),
          imageUrl: input.imageUrl || null,
          costPrice: input.costPrice.toFixed(2),
          sellingPrice: input.sellingPrice.toFixed(2),
          taxRate: "0.00",
          stockQuantity: input.stockQuantity,
          minStockAlert: input.minStockAlert,
          maxStockAlert: input.maxStockAlert,
          unit: input.unit,
        });
        return { success: true, id };
      }),

    update: adminProcedure
      .input(
        z.object({
          id: z.number(),
          sku: z.string().optional(),
          barcode: z.string().optional(),
          nameAr: z.string().optional(),
          nameEn: z.string().optional(),
          nameBn: z.string().optional(),
          category: z.string().optional(),
          imageUrl: z.string().optional(),
          costPrice: z.number().nonnegative().optional(),
          sellingPrice: z.number().nonnegative().optional(),
          taxRate: z.number().nonnegative().optional(),
          stockQuantity: z.number().int().optional(),
          minStockAlert: z.number().int().optional(),
          maxStockAlert: z.number().int().optional(),
          unit: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...rest } = input;
        const patch: Record<string, any> = {};
        if (rest.sku !== undefined) patch.sku = rest.sku;
        if (rest.barcode !== undefined) patch.barcode = rest.barcode;
        if (rest.nameAr !== undefined) patch.nameAr = rest.nameAr;
        if (rest.nameEn !== undefined) patch.nameEn = rest.nameEn;
        if (rest.nameBn !== undefined) patch.nameBn = rest.nameBn;
        if (rest.category !== undefined) patch.category = rest.category;
        if (rest.imageUrl !== undefined) patch.imageUrl = rest.imageUrl;
        if (rest.costPrice !== undefined) patch.costPrice = rest.costPrice.toFixed(2);
        if (rest.sellingPrice !== undefined) patch.sellingPrice = rest.sellingPrice.toFixed(2);
        // Tax is disabled; ignore any legacy tax-rate value sent by old clients.
        if (rest.taxRate !== undefined) patch.taxRate = "0.00";
        if (rest.stockQuantity !== undefined) patch.stockQuantity = rest.stockQuantity;
        if (rest.minStockAlert !== undefined) patch.minStockAlert = rest.minStockAlert;
        if (rest.maxStockAlert !== undefined) patch.maxStockAlert = rest.maxStockAlert;
        if (rest.unit !== undefined) patch.unit = rest.unit;

        await db.updateProduct(id, patch);
        return { success: true };
      }),

    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.deleteProduct(input.id);
      return { success: true };
    }),

    uploadImage: adminProcedure
      .input(
        z.object({
          filename: z.string().min(1).max(120),
          contentType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/i, "صيغة الصورة غير مدعومة"),
          base64Data: z.string().min(1).max(16_000_000),
        })
      )
      .mutation(async ({ input }) => {
        const buffer = Buffer.from(input.base64Data, "base64");
        if (!buffer.length || buffer.length > 12 * 1024 * 1024) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "حجم الصورة غير صالح أو أكبر من 12 ميجابايت" });
        }
        const safeFilename = input.filename.replace(/[^a-zA-Z0-9._-]/g, "-");
        const fileKey = `products/${Date.now()}-${safeFilename}`;
        const upload = await storagePut(fileKey, buffer, input.contentType);
        return { success: true, url: upload.url, key: upload.key };
      }),
  }),

  // Sales & POS Cashier
  sales: router({
    list: protectedProcedure.query(async () => {
      return db.getSalesOrders(200);
    }),

    dailySummary: protectedProcedure.query(async ({ ctx }) => {
      return db.getDailySalesSummary(ctx.staff?.staffId);
    }),

    getDetails: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const details = await db.getSalesOrderWithItems(input.id);
      if (!details) throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
      return details;
    }),

    checkout: protectedProcedure
      .input(
        z.object({
          customerNumber: z.number().int().positive(), // e.g. 55
          customerName: z.string().optional(),
          customerPhone: z.string().optional(),
          paymentMethod: z.enum(["cash", "card"]).default("cash"),
          notes: z.string().optional(),
          items: z.array(
            z.object({
              productId: z.number(),
              quantity: z.number().int().positive(),
            })
          ).min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const sellerStaffId = ctx.staff?.staffId || 1;
        const allProducts = await db.getAllProducts();
        const productMap = new Map(allProducts.map((p) => [p.id, p]));

        let subtotal = 0;
        // Tax has been disabled for this restaurant. Keep the legacy columns for historical data,
        // but all new orders must total exactly the selling-price subtotal.
        let totalTax = 0;
        let totalCost = 0;

        const orderItemsData: any[] = [];

        for (const item of input.items) {
          const product = productMap.get(item.productId);
          if (!product) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: `المنتج رقم ${item.productId} غير متوفر`,
            });
          }

          if (product.stockQuantity < item.quantity) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: `الكمية المتوفرة من ${product.nameAr} هي ${product.stockQuantity} فقط`,
            });
          }

          const unitSellingPrice = parseFloat(product.sellingPrice);
          const unitCostPrice = parseFloat(product.costPrice);
          const taxRate = 0;

          const linePrice = unitSellingPrice * item.quantity;
          const lineTax = 0;
          const lineCost = unitCostPrice * item.quantity;
          const lineTotal = linePrice + lineTax;
          const lineProfit = linePrice - lineCost;

          subtotal += linePrice;
          totalTax += lineTax;
          totalCost += lineCost;

          orderItemsData.push({
            productId: product.id,
            productName: `${product.nameAr} | ${product.nameEn}`,
            quantity: item.quantity,
            unitCostPrice: unitCostPrice.toFixed(2),
            unitSellingPrice: unitSellingPrice.toFixed(2),
            taxRate: taxRate.toFixed(2),
            taxAmount: lineTax.toFixed(2),
            lineTotal: lineTotal.toFixed(2),
            lineProfit: lineProfit.toFixed(2),
          });
        }

        const grandTotal = subtotal + totalTax;
        const netProfit = subtotal - totalCost;

        const orderNumber = `INV-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;

        const orderId = await db.createSalesOrder(
          {
            orderNumber,
            customerNumber: input.customerNumber,
            customerName: input.customerName?.trim() || null,
            customerPhone: input.customerPhone?.trim() || null,
            sellerStaffId,
            subtotal: subtotal.toFixed(2),
            totalTax: totalTax.toFixed(2),
            totalCost: totalCost.toFixed(2),
            grandTotal: grandTotal.toFixed(2),
            netProfit: netProfit.toFixed(2),
            paymentMethod: input.paymentMethod,
            status: "completed",
            notes: input.notes || null,
          },
          orderItemsData
        );

        return {
          success: true,
          orderId,
          orderNumber,
          customerNumber: input.customerNumber,
          grandTotal: grandTotal.toFixed(2),
          totalTax: totalTax.toFixed(2),
          netProfit: netProfit.toFixed(2),
        };
      }),

    cancelOrder: adminProcedure
      .input(
        z.object({
          orderId: z.number(),
          reason: z.string().min(2),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const staffId = ctx.staff?.staffId || 1;
        await db.cancelSalesOrder(input.orderId, staffId, input.reason);
        return { success: true };
      }),

    updateStatus: protectedProcedure
      .input(z.object({ orderId: z.number(), status: z.literal("cancelled"), reason: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const staffId = ctx.staff?.staffId || 1;
        await db.cancelSalesOrder(input.orderId, staffId, input.reason || "أُلغي من شاشة الطلبات");
        return { success: true };
      }),
  }),

  // Stocktake (الجرد اليومي والأسبوعي)
  stocktake: router({
    list: protectedProcedure.query(async () => {
      return db.getStocktakeSessions();
    }),

    getDetails: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const details = await db.getStocktakeDetails(input.id);
      if (!details) throw new TRPCError({ code: "NOT_FOUND", message: "جلسة الجرد غير موجودة" });
      return details;
    }),

    createSession: adminProcedure
      .input(
        z.object({
          title: z.string().min(1),
          cycleType: z.enum(["daily", "weekly", "adhoc"]).default("daily"),
          assignedToStaffId: z.number().optional(),
          notes: z.string().optional(),
          notifyStaff: z.boolean().default(true),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const requestedByStaffId = ctx.staff?.staffId || 1;
        const sessionCode = `STK-${Date.now().toString().slice(-6)}`;

        const sessionId = await db.createStocktakeSession({
          sessionCode,
          title: input.title.trim(),
          cycleType: input.cycleType,
          status: "requested",
          requestedByStaffId,
          assignedToStaffId: input.assignedToStaffId || null,
          notes: input.notes || null,
        });

        if (input.notifyStaff) {
          const typeLabel =
            input.cycleType === "daily"
              ? "اليومي"
              : input.cycleType === "weekly"
              ? "الأسبوعي"
              : "الفوري";
          await db.createStaffNotification({
            senderStaffId: requestedByStaffId,
            targetStaffId: input.assignedToStaffId || null,
            titleAr: `مطلوب جرد المخزون ${typeLabel}`,
            titleEn: `Stocktake Requested (${input.cycleType})`,
            titleBn: `মজুদ গণনা প্রয়োজন (${input.cycleType})`,
            messageAr: `يرجى من العمال البدء في جرد المخزون الآن لجلسة: ${input.title}`,
            messageEn: `Staff is requested to perform stocktake now for session: ${input.title}`,
            messageBn: `অনুগ্রহ করে এখন পণ্য গণনা শুরু করুন: ${input.title}`,
            type: "stocktake_alert",
            referenceId: sessionCode,
          });
        }

        return { success: true, sessionId, sessionCode };
      }),

    submitItemCount: protectedProcedure
      .input(
        z.object({
          itemId: z.number(),
          actualQuantity: z.number().int().nonnegative(),
          remarks: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const staffId = ctx.staff?.staffId || 1;
        await db.updateStocktakeItemCount(
          input.itemId,
          input.actualQuantity,
          staffId,
          input.remarks
        );
        return { success: true };
      }),

    completeSession: adminProcedure
      .input(
        z.object({
          sessionId: z.number(),
          applyToInventory: z.boolean().default(true),
        })
      )
      .mutation(async ({ input }) => {
        await db.completeStocktakeSession(input.sessionId, input.applyToInventory);
        return { success: true };
      }),
  }),

  // Notifications & Alerts System
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const staffId = ctx.staff?.staffId;
      return db.getStaffNotifications(staffId);
    }),

    sendAlert: adminProcedure
      .input(
        z.object({
          targetStaffId: z.number().optional(), // null means all
          titleAr: z.string().min(1),
          titleEn: z.string().min(1),
          titleBn: z.string().min(1),
          messageAr: z.string().min(1),
          messageEn: z.string().min(1),
          messageBn: z.string().min(1),
          type: z
            .enum(["stocktake_alert", "low_stock", "announcement", "general"])
            .default("general"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const senderStaffId = ctx.staff?.staffId || 1;
        const id = await db.createStaffNotification({
          senderStaffId,
          targetStaffId: input.targetStaffId || null,
          titleAr: input.titleAr,
          titleEn: input.titleEn,
          titleBn: input.titleBn,
          messageAr: input.messageAr,
          messageEn: input.messageEn,
          messageBn: input.messageBn,
          type: input.type,
        });

        return { success: true, id };
      }),

    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),
  }),

  // Analytics & Admin Reports (Profits, Costs, Tax, Margins, Stock levels)
  reports: router({
    dashboardSummary: adminProcedure.query(async () => {
      return db.getDashboardStats();
    }),
  }),
});

export type AppRouter = typeof appRouter;
