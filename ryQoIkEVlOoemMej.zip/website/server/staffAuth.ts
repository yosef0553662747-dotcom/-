import { SignJWT, jwtVerify } from "jose";
import crypto from "crypto";

const JWT_SECRET_STRING = process.env.JWT_SECRET || "sallaq-super-secret-pos-jwt-key-2026";
const SECRET_KEY = new TextEncoder().encode(JWT_SECRET_STRING);

export interface StaffSessionPayload {
  staffId: number;
  username: string;
  fullName: string;
  role: "admin" | "worker" | "developer";
  preferredLanguage: "ar" | "en" | "bn";
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.includes(":")) {
    // fallback for plain comparison if any legacy
    return password === storedHash;
  }
  const [salt, originalHash] = storedHash.split(":");
  const testHash = crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
  return originalHash === testHash;
}

export async function signStaffToken(payload: StaffSessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(SECRET_KEY);
}

export async function verifyStaffToken(token: string): Promise<StaffSessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET_KEY);
    return {
      staffId: Number(payload.staffId),
      username: String(payload.username),
      fullName: String(payload.fullName),
      role: payload.role as "admin" | "worker" | "developer",
      preferredLanguage: (payload.preferredLanguage as "ar" | "en" | "bn") || "ar",
    };
  } catch (error) {
    return null;
  }
}
