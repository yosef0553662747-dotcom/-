import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { hashPassword, verifyPassword } from "./staffAuth";

function createMockContext(staff?: any): TrpcContext {
  return {
    user: null,
    staff: staff || null,
    req: {
      protocol: "https",
      headers: {},
    } as any,
    res: {
      cookie: () => {},
      clearCookie: () => {},
    } as any,
  };
}

describe("Sallaq POS Core Logic Tests", () => {
  it("hashes and verifies staff password accurately", () => {
    const raw = "worker123";
    const hash = hashPassword(raw);
    expect(hash).toContain(":");
    expect(verifyPassword(raw, hash)).toBe(true);
    expect(verifyPassword("wrongpass", hash)).toBe(false);
  });

  it("fails staff login with invalid credentials", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.auth.loginStaff({
        username: "non_existent_worker_xyz",
        password: "randompassword",
      })
    ).rejects.toThrow();
  });

  it("retrieves product catalog with prices and stock", async () => {
    const ctx = createMockContext({
      staffId: 1,
      username: "salim",
      fullName: "سالم المري",
      role: "worker",
      preferredLanguage: "ar",
    });
    const caller = appRouter.createCaller(ctx);
    const products = await caller.products.list();

    expect(Array.isArray(products)).toBe(true);
    expect(products.length).toBeGreaterThan(0);
    const first = products[0];
    expect(first).toHaveProperty("sellingPrice");
    expect(first).toHaveProperty("costPrice");
    expect(first).toHaveProperty("taxRate");
    expect(first).toHaveProperty("stockQuantity");
  });

  it("calculates dashboard summaries for admin correctly", async () => {
    const ctx = createMockContext({
      staffId: 1,
      username: "admin",
      fullName: "أبو فهد",
      role: "admin",
      preferredLanguage: "ar",
    });
    const caller = appRouter.createCaller(ctx);
    const stats = await caller.reports.dashboardSummary();

    expect(stats).toHaveProperty("totalSales");
    expect(stats).toHaveProperty("totalCost");
    expect(stats).toHaveProperty("totalTax");
    expect(stats).toHaveProperty("netProfit");
    expect(stats.totalSales).toBeGreaterThanOrEqual(0);
  });

  it("prevents workers from accessing admin restricted routers", async () => {
    const workerCtx = createMockContext({
      staffId: 2,
      username: "worker",
      fullName: "Worker Name",
      role: "worker",
      preferredLanguage: "ar",
    });
    const caller = appRouter.createCaller(workerCtx);

    await expect(caller.staff.list()).rejects.toThrow("Admin privileges required");
  });
});
