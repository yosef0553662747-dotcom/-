import { and, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertProduct,
  InsertSalesOrder,
  InsertSalesOrderItem,
  InsertStaffAccount,
  InsertStaffNotification,
  InsertStocktakeItem,
  InsertStocktakeSession,
  InsertUser,
  Product,
  products,
  SalesOrder,
  salesOrderItems,
  salesOrders,
  StaffAccount,
  staffAccounts,
  StaffNotification,
  staffNotifications,
  StocktakeItem,
  stocktakeItems,
  StocktakeSession,
  stocktakeSessions,
  users,
  appSettings,
  InsertMenuSection,
  MenuSection,
  menuSections,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  if (user.name !== undefined) {
    values.name = user.name;
    updateSet.name = user.name;
  }
  if (user.email !== undefined) {
    values.email = user.email;
    updateSet.email = user.email;
  }
  if (user.loginMethod !== undefined) {
    values.loginMethod = user.loginMethod;
    updateSet.loginMethod = user.loginMethod;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  }

  values.lastSignedIn = user.lastSignedIn || new Date();
  updateSet.lastSignedIn = values.lastSignedIn;

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// Staff queries
export async function getStaffByUsername(username: string): Promise<StaffAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const res = await db.select().from(staffAccounts).where(eq(staffAccounts.username, username)).limit(1);
  return res[0];
}

export async function getStaffById(id: number): Promise<StaffAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const res = await db.select().from(staffAccounts).where(eq(staffAccounts.id, id)).limit(1);
  return res[0];
}

export async function getAllStaff(): Promise<StaffAccount[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(staffAccounts).orderBy(desc(staffAccounts.createdAt));
}

export async function createStaffAccount(data: InsertStaffAccount): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  const res = await db.insert(staffAccounts).values(data);
  return res[0].insertId;
}

export async function updateStaffAccount(id: number, data: Partial<InsertStaffAccount>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.update(staffAccounts).set(data).where(eq(staffAccounts.id, id));
}

export async function deleteStaffAccount(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.delete(staffAccounts).where(eq(staffAccounts.id, id));
}

export async function getAppSettings(): Promise<Record<string, string>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db.select().from(appSettings);
  return Object.fromEntries(rows.map((row) => [row.settingKey, row.settingValue || ""]));
}

export async function saveAppSettings(values: Record<string, string>, updatedByStaffId?: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  for (const [settingKey, settingValue] of Object.entries(values)) {
    await db.insert(appSettings).values({ settingKey, settingValue, updatedByStaffId: updatedByStaffId || null }).onDuplicateKeyUpdate({
      set: { settingValue, updatedByStaffId: updatedByStaffId || null },
    });
  }
}

// Developer-managed menu sections
export async function getMenuSections(includeInactive = false): Promise<MenuSection[]> {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(menuSections);
  return includeInactive
    ? query.orderBy(menuSections.displayOrder, menuSections.id)
    : query.where(eq(menuSections.isActive, 1)).orderBy(menuSections.displayOrder, menuSections.id);
}

export async function createMenuSection(data: InsertMenuSection): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  const [res] = await db.insert(menuSections).values(data);
  return res.insertId;
}

export async function updateMenuSection(id: number, data: Partial<InsertMenuSection>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.update(menuSections).set(data).where(eq(menuSections.id, id));
}

export async function deleteMenuSection(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.delete(menuSections).where(eq(menuSections.id, id));
}

// Products queries
export async function getAllProducts(): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).orderBy(desc(products.id));
}

export async function getProductById(id: number): Promise<Product | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const res = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return res[0];
}

export async function createProduct(data: InsertProduct): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  const res = await db.insert(products).values(data);
  return res[0].insertId;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.delete(products).where(eq(products.id, id));
}

export async function updateProductStock(id: number, delta: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.update(products).set({
    stockQuantity: sql`${products.stockQuantity} + ${delta}`,
  }).where(eq(products.id, id));
}

// Sales Orders
export async function getSalesOrders(limit = 100): Promise<SalesOrder[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(salesOrders).orderBy(desc(salesOrders.createdAt)).limit(limit);
}

export async function getSalesOrderWithItems(orderId: number) {
  const db = await getDb();
  if (!db) return null;
  const orderRes = await db.select().from(salesOrders).where(eq(salesOrders.id, orderId)).limit(1);
  if (!orderRes[0]) return null;
  const items = await db.select().from(salesOrderItems).where(eq(salesOrderItems.orderId, orderId));
  return { order: orderRes[0], items };
}

export async function getDailySalesSummary(staffId?: number) {
  const db = await getDb();
  if (!db) return { date: new Date().toISOString().slice(0, 10), cash: 0, card: 0, total: 0, orders: 0, cancelledOrders: 0, weeklyOrders: 0, lastStocktake: null, items: [] as Array<{ productName: string; quantity: number }> };
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(); end.setHours(23, 59, 59, 999);
  const weekStart = new Date(start); weekStart.setDate(start.getDate() - start.getDay());
  const conditions = [eq(salesOrders.status, "completed"), gte(salesOrders.createdAt, start), lte(salesOrders.createdAt, end)];
  if (staffId) conditions.push(eq(salesOrders.sellerStaffId, staffId));
  const orders = await db.select().from(salesOrders).where(and(...conditions));
  const weeklyConditions = [eq(salesOrders.status, "completed"), gte(salesOrders.createdAt, weekStart), lte(salesOrders.createdAt, end)];
  if (staffId) weeklyConditions.push(eq(salesOrders.sellerStaffId, staffId));
  const weeklyOrders = await db.select({ id: salesOrders.id }).from(salesOrders).where(and(...weeklyConditions));
  const cancelledConditions = [eq(salesOrders.status, "cancelled"), gte(salesOrders.createdAt, start), lte(salesOrders.createdAt, end)];
  if (staffId) cancelledConditions.push(eq(salesOrders.sellerStaffId, staffId));
  const cancelledOrders = await db.select({ id: salesOrders.id }).from(salesOrders).where(and(...cancelledConditions));
  const [lastStocktake] = await db.select({ completedAt: stocktakeSessions.completedAt, createdAt: stocktakeSessions.createdAt }).from(stocktakeSessions).where(eq(stocktakeSessions.status, "completed")).orderBy(desc(stocktakeSessions.completedAt), desc(stocktakeSessions.createdAt)).limit(1);
  const quantities = new Map<string, number>();
  if (orders.length > 0) {
    const orderItems = await db.select().from(salesOrderItems).where(inArray(salesOrderItems.orderId, orders.map((order) => order.id)));
    for (const item of orderItems) {
      const productName = item.productName.split(" | ")[0];
      quantities.set(productName, (quantities.get(productName) || 0) + item.quantity);
    }
  }
  const cash = orders.filter((o) => o.paymentMethod === "cash").reduce((sum, o) => sum + parseFloat(o.grandTotal), 0);
  const card = orders.filter((o) => o.paymentMethod === "card").reduce((sum, o) => sum + parseFloat(o.grandTotal), 0);
  return { date: start.toISOString().slice(0, 10), cash, card, total: cash + card, orders: orders.length, cancelledOrders: cancelledOrders.length, weeklyOrders: weeklyOrders.length, lastStocktake: lastStocktake || null, items: Array.from(quantities, ([productName, quantity]) => ({ productName, quantity })) };
}

export async function createSalesOrder(
  order: InsertSalesOrder,
  items: Array<Omit<InsertSalesOrderItem, "orderId">>
): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const [orderResult] = await db.insert(salesOrders).values(order);
  const orderId = orderResult.insertId;

  if (items.length > 0) {
    const itemValues = items.map((it) => ({
      ...it,
      orderId,
    }));
    await db.insert(salesOrderItems).values(itemValues);

    // Decrement stock for completed orders.
    if (order.status === "completed") {
      for (const item of items) {
        await updateProductStock(item.productId, -item.quantity);
      }
    }
  }

  return orderId;
}

export async function cancelSalesOrder(orderId: number, cancelledByStaffId: number, reason: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const orderRes = await db.select().from(salesOrders).where(eq(salesOrders.id, orderId)).limit(1);
  const order = orderRes[0];
  if (!order || order.status === "cancelled") return;

  // Restore inventory
  const items = await db.select().from(salesOrderItems).where(eq(salesOrderItems.orderId, orderId));
  for (const item of items) {
    await updateProductStock(item.productId, item.quantity);
  }

  await db.update(salesOrders).set({
    status: "cancelled",
    cancelReason: reason,
    cancelledByStaffId,
  }).where(eq(salesOrders.id, orderId));
}

export async function updateSalesOrderStatus(orderId: number, staffId: number, status: "completed" | "cancelled", reason?: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  const [order] = await db.select().from(salesOrders).where(eq(salesOrders.id, orderId)).limit(1);
  if (!order) throw new Error("الطلب غير موجود");
  if (order.status === status) return;
  if (order.status === "cancelled" || order.status === "completed") throw new Error("لا يمكن تعديل حالة طلب نهائي");

  if (status === "cancelled") {
    const items = await db.select().from(salesOrderItems).where(eq(salesOrderItems.orderId, orderId));
    for (const item of items) await updateProductStock(item.productId, item.quantity);
  }
  await db.update(salesOrders).set({
    status,
    cancelReason: status === "cancelled" ? (reason || "أُلغي الطلب") : null,
    cancelledByStaffId: status === "cancelled" ? staffId : null,
  }).where(eq(salesOrders.id, orderId));
}

// Stocktaking
export async function getStocktakeSessions(): Promise<StocktakeSession[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stocktakeSessions).orderBy(desc(stocktakeSessions.createdAt));
}

export async function getStocktakeDetails(sessionId: number) {
  const db = await getDb();
  if (!db) return null;
  const sessionRes = await db.select().from(stocktakeSessions).where(eq(stocktakeSessions.id, sessionId)).limit(1);
  if (!sessionRes[0]) return null;
  const items = await db.select().from(stocktakeItems).where(eq(stocktakeItems.sessionId, sessionId));
  return { session: sessionRes[0], items };
}

export async function createStocktakeSession(
  sessionData: InsertStocktakeSession
): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const [res] = await db.insert(stocktakeSessions).values(sessionData);
  const sessionId = res.insertId;

  // Populate snapshot of current product stocks
  const currentProducts = await getAllProducts();
  if (currentProducts.length > 0) {
    const snapItems: InsertStocktakeItem[] = currentProducts.map((p) => ({
      sessionId,
      productId: p.id,
      expectedQuantity: p.stockQuantity,
      actualQuantity: null,
      difference: null,
      costDifference: "0.00",
    }));
    await db.insert(stocktakeItems).values(snapItems);
  }

  return sessionId;
}

export async function updateStocktakeItemCount(
  itemId: number,
  actualQuantity: number,
  countedByStaffId: number,
  remarks?: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  const itemRes = await db.select().from(stocktakeItems).where(eq(stocktakeItems.id, itemId)).limit(1);
  const item = itemRes[0];
  if (!item) return;

  const productRes = await db.select().from(products).where(eq(products.id, item.productId)).limit(1);
  const product = productRes[0];
  const unitCost = product ? parseFloat(product.costPrice) : 0;

  const diff = actualQuantity - item.expectedQuantity;
  const costDiff = (diff * unitCost).toFixed(2);

  await db.update(stocktakeItems).set({
    actualQuantity,
    difference: diff,
    costDifference: costDiff,
    countedByStaffId,
    remarks: remarks || item.remarks,
    countedAt: new Date(),
  }).where(eq(stocktakeItems.id, itemId));
}

export async function completeStocktakeSession(sessionId: number, applyToInventory = true): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");

  await db.update(stocktakeSessions).set({
    status: "completed",
    completedAt: new Date(),
  }).where(eq(stocktakeSessions.id, sessionId));

  if (applyToInventory) {
    const counted = await db.select().from(stocktakeItems).where(eq(stocktakeItems.sessionId, sessionId));
    for (const item of counted) {
      if (item.actualQuantity !== null && item.actualQuantity !== undefined) {
        await db.update(products).set({
          stockQuantity: item.actualQuantity,
        }).where(eq(products.id, item.productId));
      }
    }
  }
}

// Notifications
export async function createStaffNotification(data: InsertStaffNotification): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  const [res] = await db.insert(staffNotifications).values(data);
  return res.insertId;
}

export async function getStaffNotifications(staffId?: number): Promise<StaffNotification[]> {
  const db = await getDb();
  if (!db) return [];
  if (!staffId) {
    return db.select().from(staffNotifications).orderBy(desc(staffNotifications.createdAt)).limit(50);
  }
  return db
    .select()
    .from(staffNotifications)
    .where(
      sql`${staffNotifications.targetStaffId} IS NULL OR ${staffNotifications.targetStaffId} = ${staffId}`
    )
    .orderBy(desc(staffNotifications.createdAt))
    .limit(50);
}

export async function markNotificationAsRead(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  await db.update(staffNotifications).set({ isRead: 1 }).where(eq(staffNotifications.id, id));
}

// Summary and Reports
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) {
    return {
      totalSales: 0,
      totalCost: 0,
      totalTax: 0,
      netProfit: 0,
      completedOrdersCount: 0,
      cancelledOrdersCount: 0,
      totalProductsCount: 0,
      lowStockProductsCount: 0,
    };
  }

  const [salesAgg] = await db
    .select({
      totalSales: sql<string>`COALESCE(SUM(CASE WHEN status = 'completed' THEN grandTotal ELSE 0 END), '0')`,
      totalCost: sql<string>`COALESCE(SUM(CASE WHEN status = 'completed' THEN totalCost ELSE 0 END), '0')`,
      totalTax: sql<string>`COALESCE(SUM(CASE WHEN status = 'completed' THEN totalTax ELSE 0 END), '0')`,
      netProfit: sql<string>`COALESCE(SUM(CASE WHEN status = 'completed' THEN netProfit ELSE 0 END), '0')`,
      completedOrdersCount: sql<number>`SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END)`,
      cancelledOrdersCount: sql<number>`SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END)`,
    })
    .from(salesOrders);

  const [productsAgg] = await db
    .select({
      totalProductsCount: sql<number>`COUNT(*)`,
      lowStockProductsCount: sql<number>`SUM(CASE WHEN stockQuantity <= minStockAlert THEN 1 ELSE 0 END)`,
    })
    .from(products);

  return {
    totalSales: parseFloat(salesAgg?.totalSales || "0"),
    totalCost: parseFloat(salesAgg?.totalCost || "0"),
    totalTax: parseFloat(salesAgg?.totalTax || "0"),
    netProfit: parseFloat(salesAgg?.netProfit || "0"),
    completedOrdersCount: Number(salesAgg?.completedOrdersCount || 0),
    cancelledOrdersCount: Number(salesAgg?.cancelledOrdersCount || 0),
    totalProductsCount: Number(productsAgg?.totalProductsCount || 0),
    lowStockProductsCount: Number(productsAgg?.lowStockProductsCount || 0),
  };
}

export async function getStaffPerformance() {
  const db = await getDb();
  if (!db) return [];

  const staffList = await db.select().from(staffAccounts);

  const performance = await Promise.all(
    staffList.map(async (st) => {
      const [stats] = await db
        .select({
          completedSalesCount: sql<number>`SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END)`,
          completedSalesAmount: sql<string>`COALESCE(SUM(CASE WHEN status = 'completed' THEN grandTotal ELSE 0 END), '0')`,
          cancelledOrdersCount: sql<number>`SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END)`,
          cancelledSalesAmount: sql<string>`COALESCE(SUM(CASE WHEN status = 'cancelled' THEN grandTotal ELSE 0 END), '0')`,
        })
        .from(salesOrders)
        .where(eq(salesOrders.sellerStaffId, st.id));

      return {
        staffId: st.id,
        username: st.username,
        fullName: st.fullName,
        role: st.role,
        preferredLanguage: st.preferredLanguage,
        completedSalesCount: Number(stats?.completedSalesCount || 0),
        completedSalesAmount: parseFloat(stats?.completedSalesAmount || "0"),
        cancelledOrdersCount: Number(stats?.cancelledOrdersCount || 0),
        cancelledSalesAmount: parseFloat(stats?.cancelledSalesAmount || "0"),
      };
    })
  );

  return performance;
}

export async function getStaffSalesDetails(staffId: number) {
  const db = await getDb();
  if (!db) return [];

  const orders = await db.select().from(salesOrders)
    .where(eq(salesOrders.sellerStaffId, staffId))
    .orderBy(desc(salesOrders.createdAt));

  return Promise.all(orders.map(async (order) => {
    const items = await db.select().from(salesOrderItems)
      .where(eq(salesOrderItems.orderId, order.id));
    const detailedItems = await Promise.all(items.map(async (item) => {
      const product = await getProductById(item.productId);
      return {
        ...item,
        productName: product?.nameAr || `منتج #${item.productId}`,
      };
    }));
    return { order, items: detailedItems };
  }));
}
