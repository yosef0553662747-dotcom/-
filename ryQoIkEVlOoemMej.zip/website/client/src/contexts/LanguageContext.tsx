import React, { createContext, useContext, useEffect, useState } from "react";
import { Language, translations, Translations } from "../i18n";
import { trpc } from "../lib/trpc";

interface LanguageContextType {
  language: Language;
  t: Translations;
  setLanguage: (lang: Language) => void;
  dir: "rtl" | "ltr";
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("sallaq_pos_lang") as Language;
    if (saved && ["ar", "en", "bn"].includes(saved)) {
      return saved;
    }
    return "ar";
  });

  const switchMutation = trpc.auth.switchLanguage.useMutation();

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("sallaq_pos_lang", lang);
    switchMutation.mutate({ language: lang });
  };

  const dir: "rtl" | "ltr" = language === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
  }, [dir, language]);

  return (
    <LanguageContext.Provider
      value={{
        language,
        t: translations[language],
        setLanguage,
        dir,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
