export type Language = "ar" | "en" | "bn";

export interface Translations {
  appName: string;
  appSubtitle: string;
  login: string;
  logout: string;
  welcome: string;
  role: string;
  admin: string;
  worker: string;
  username: string;
  password: string;
  fullName: string;
  phone: string;
  loginAsWorker: string;
  loginAsAdmin: string;
  enterUsername: string;
  enterPassword: string;
  loginButton: string;
  portalTitleWorker: string;
  portalTitleAdmin: string;
  dashboard: string;
  posCashier: string;
  productsAndStock: string;
  inventoryStocktake: string;
  ordersAndSales: string;
  staffManagement: string;
  reportsAndProfits: string;
  notifications: string;
  totalSales: string;
  totalCost: string;
  totalTax: string;
  netProfit: string;
  profitMargin: string;
  completedOrders: string;
  cancelledOrders: string;
  lowStockItems: string;
  totalProducts: string;
  orderNumber: string;
  customerNumber: string;
  customerName: string;
  customerPhone: string;
  itemsPurchased: string;
  quantity: string;
  price: string;
  cost: string;
  tax: string;
  grandTotal: string;
  paymentMethod: string;
  cash: string;
  card: string;
  online: string;
  credit: string;
  status: string;
  completed: string;
  cancelled: string;
  actions: string;
  cancelOrder: string;
  cancelReason: string;
  submitSale: string;
  addToCart: string;
  cart: string;
  emptyCart: string;
  productImage: string;
  uploadImage: string;
  sku: string;
  barcode: string;
  nameAr: string;
  nameEn: string;
  nameBn: string;
  sellingPrice: string;
  costPrice: string;
  taxRate: string;
  stockQuantity: string;
  stockRange: string;
  minStock: string;
  maxStock: string;
  addProduct: string;
  editProduct: string;
  deleteProduct: string;
  stocktakeTitle: string;
  newStocktake: string;
  cycleType: string;
  daily: string;
  weekly: string;
  adhoc: string;
  sendStocktakeAlert: string;
  stocktakePromptWorker: string;
  expectedQty: string;
  actualCount: string;
  difference: string;
  costVariance: string;
  completeStocktake: string;
  applyToStock: string;
  sendNotification: string;
  sendToAll: string;
  sendToWorker: string;
  title: string;
  message: string;
  sendNow: string;
  staffPerformance: string;
  salesCount: string;
  salesAmount: string;
  cancelledCount: string;
  cancelledAmount: string;
  preferredLanguage: string;
  switchLanguage: string;
  currency: string;
  arabic: string;
  english: string;
  bengali: string;
  searchProduct: string;
  filterByStatus: string;
  all: string;
  saveChanges: string;
  confirm: string;
  cancel: string;
  success: string;
  error: string;
}

export const translations: Record<Language, Translations> = {
  ar: {
    appName: "نظام مبيعات مطعم ديوانية مدهال",
    appSubtitle: "نظام إدارة المبيعات والمخزون والجرد المتعدد اللغات",
    login: "تسجيل الدخول",
    logout: "تسجيل الخروج",
    welcome: "مرحباً بك",
    role: "الصلاحية",
    admin: "الإدارة",
    worker: "عامل / كاشير",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    fullName: "الاسم الكامل",
    phone: "رقم الجوال",
    loginAsWorker: "دخول العمال (نقطة البيع والجرد)",
    loginAsAdmin: "دخول الإدارة (التقارير والأرباح والمنتجات)",
    enterUsername: "أدخل اسم المستخدم",
    enterPassword: "أدخل كلمة المرور",
    loginButton: "دخول النظام",
    portalTitleWorker: "بوابة العمال ونقاط البيع",
    portalTitleAdmin: "لوحة تحكم الإدارة المالية والتشغيلية",
    dashboard: "الرئيسية",
    posCashier: "نقطة البيع (الكاشير)",
    productsAndStock: "إدارة المنتجات والمخزون",
    inventoryStocktake: "الجرد الدوري (يومي / أسبوعي)",
    ordersAndSales: "سجل المبيعات والفواتير",
    staffManagement: "إدارة حسابات العمال",
    reportsAndProfits: "الأرباح والتكاليف والضريبة",
    notifications: "التنبيهات والإشعارات",
    totalSales: "إجمالي المبيعات",
    totalCost: "إجمالي التكلفة",
    totalTax: "إجمالي الضريبة (15%)",
    netProfit: "صافي الأرباح",
    profitMargin: "هامش الربح",
    completedOrders: "طلبات مكتملة",
    cancelledOrders: "طلبات ملغاة",
    lowStockItems: "منتجات قاربت على النفاد",
    totalProducts: "إجمالي المنتجات",
    orderNumber: "رقم الفاتورة",
    customerNumber: "رقم الزبون",
    customerName: "اسم الزبون",
    customerPhone: "جوال الزبون",
    itemsPurchased: "المنتجات المشتراة",
    quantity: "الكمية",
    price: "السعر",
    cost: "التكلفة",
    tax: "الضريبة",
    grandTotal: "الإجمالي النهائي",
    paymentMethod: "طريقة الدفع",
    cash: "نقداً (كاش)",
    card: "بطاقة مدى / ائتمان",
    online: "تحويل إلكتروني",
    credit: "آجل",
    status: "الحالة",
    completed: "مكتمل",
    cancelled: "ملغي",
    actions: "الإجراءات",
    cancelOrder: "إلغاء الطلب",
    cancelReason: "سبب الإلغاء",
    submitSale: "إتمام عملية البيع وطباعة الفاتورة",
    addToCart: "إضافة للسلة",
    cart: "سلة المشتريات",
    emptyCart: "السلة فارغة، اختر المنتجات للبدء",
    productImage: "صورة المنتج",
    uploadImage: "رفع صورة",
    sku: "رمز المنتج (SKU)",
    barcode: "الباركود",
    nameAr: "الاسم بالعربية",
    nameEn: "الاسم بالإنجليزية",
    nameBn: "الاسم بالبنغالية",
    sellingPrice: "سعر البيع",
    costPrice: "سعر التكلفة",
    taxRate: "نسبة الضريبة %",
    stockQuantity: "الكمية المتوفرة",
    stockRange: "مستوى المخزون التقريبي",
    minStock: "الحد الأدنى للتنبيه",
    maxStock: "الحد المستهدف",
    addProduct: "إضافة منتج جديد",
    editProduct: "تعديل المنتج",
    deleteProduct: "حذف المنتج",
    stocktakeTitle: "جلسات الجرد",
    newStocktake: "بدء جلسة جرد جديدة",
    cycleType: "دورة الجرد",
    daily: "يومي",
    weekly: "أسبوعي",
    adhoc: "فوري",
    sendStocktakeAlert: "إرسال إشعار للعمال للبدء بالجرد",
    stocktakePromptWorker: "سوو جرد الآن للمخزون وسجّلوا الكميات الفعلية",
    expectedQty: "الكمية المتوقعة بالنظام",
    actualCount: "العدد الفعلي بالجرد",
    difference: "الفرق (عجز / زيادة)",
    costVariance: "فارق القيمة المالية",
    completeStocktake: "اعتماد وإنهاء الجرد وتحديث المخزون",
    applyToStock: "تحديث المخزون تلقائياً بالكميات الفعلية",
    sendNotification: "إرسال تنبيه أو إشعار فوري",
    sendToAll: "جميع العمال",
    sendToWorker: "عامل محدد",
    title: "عنوان الإشعار",
    message: "نص الرسالة",
    sendNow: "إرسال التنبيه الآن",
    staffPerformance: "أداء ومبيعات العمال",
    salesCount: "عدد عمليات البيع",
    salesAmount: "إجمالي مبيعات العامل",
    cancelledCount: "الطلبات الملغاة للعامل",
    cancelledAmount: "قيمة المبيعات الملغاة",
    preferredLanguage: "اللغة المفضلة",
    switchLanguage: "تغيير اللغة",
    currency: "ر.س",
    arabic: "العربية",
    english: "English",
    bengali: "বাংলা",
    searchProduct: "بحث باسم المنتج أو الباركود...",
    filterByStatus: "تصفية بالحالة",
    all: "الكل",
    saveChanges: "حفظ التغييرات",
    confirm: "تأكيد",
    cancel: "إلغاء",
    success: "تمت العملية بنجاح",
    error: "حدث خطأ أثناء المعالجة",
  },
  en: {
    appName: "Diwaniya Madhhal Restaurant Sales System",
    appSubtitle: "Multilingual Sales, Inventory & Stocktaking Management",
    login: "Sign In",
    logout: "Sign Out",
    welcome: "Welcome",
    role: "Role",
    admin: "Management",
    worker: "Worker / Cashier",
    username: "Username",
    password: "Password",
    fullName: "Full Name",
    phone: "Phone Number",
    loginAsWorker: "Worker Sign In (POS & Stocktaking)",
    loginAsAdmin: "Admin Sign In (Profits, Inventory & Products)",
    enterUsername: "Enter username",
    enterPassword: "Enter password",
    loginButton: "Log In",
    portalTitleWorker: "Worker & Cashier POS Portal",
    portalTitleAdmin: "Executive & Financial Management Portal",
    dashboard: "Dashboard",
    posCashier: "Point of Sale (POS)",
    productsAndStock: "Products & Stock",
    inventoryStocktake: "Stocktake (Daily / Weekly)",
    ordersAndSales: "Sales Orders & History",
    staffManagement: "Staff Accounts",
    reportsAndProfits: "Profits, Costs & VAT",
    notifications: "Alerts & Notifications",
    totalSales: "Total Sales",
    totalCost: "Total Cost",
    totalTax: "Total VAT (15%)",
    netProfit: "Net Profit",
    profitMargin: "Profit Margin",
    completedOrders: "Completed Orders",
    cancelledOrders: "Cancelled Orders",
    lowStockItems: "Low Stock Items",
    totalProducts: "Total Products",
    orderNumber: "Invoice No.",
    customerNumber: "Customer No.",
    customerName: "Customer Name",
    customerPhone: "Customer Phone",
    itemsPurchased: "Items Purchased",
    quantity: "Qty",
    price: "Price",
    cost: "Cost",
    tax: "VAT",
    grandTotal: "Grand Total",
    paymentMethod: "Payment Method",
    cash: "Cash",
    card: "Card / Mada",
    online: "Electronic Transfer",
    credit: "On Credit",
    status: "Status",
    completed: "Completed",
    cancelled: "Cancelled",
    actions: "Actions",
    cancelOrder: "Cancel Order",
    cancelReason: "Cancellation Reason",
    submitSale: "Complete Sale & Print Receipt",
    addToCart: "Add to Cart",
    cart: "Shopping Cart",
    emptyCart: "Cart is empty, select items to start",
    productImage: "Product Image",
    uploadImage: "Upload Image",
    sku: "SKU Code",
    barcode: "Barcode",
    nameAr: "Name (Arabic)",
    nameEn: "Name (English)",
    nameBn: "Name (Bengali)",
    sellingPrice: "Selling Price",
    costPrice: "Cost Price",
    taxRate: "VAT Rate %",
    stockQuantity: "Stock Quantity",
    stockRange: "Stock Range Status",
    minStock: "Min Alert Level",
    maxStock: "Target Level",
    addProduct: "Add New Product",
    editProduct: "Edit Product",
    deleteProduct: "Delete Product",
    stocktakeTitle: "Stocktaking Sessions",
    newStocktake: "New Stocktake Session",
    cycleType: "Cycle Type",
    daily: "Daily",
    weekly: "Weekly",
    adhoc: "Instant / Ad-hoc",
    sendStocktakeAlert: "Send Stocktake Notification to Staff",
    stocktakePromptWorker: "Please conduct inventory count now and record physical quantities",
    expectedQty: "System Expected Qty",
    actualCount: "Actual Counted Qty",
    difference: "Variance",
    costVariance: "Financial Cost Variance",
    completeStocktake: "Finalize & Update Inventory",
    applyToStock: "Automatically apply counted quantities to stock",
    sendNotification: "Send Instant Broadcast Alert",
    sendToAll: "All Staff",
    sendToWorker: "Specific Worker",
    title: "Alert Title",
    message: "Message Body",
    sendNow: "Send Alert Now",
    staffPerformance: "Staff Sales Performance",
    salesCount: "Total Sales Orders",
    salesAmount: "Total Sales Amount",
    cancelledCount: "Cancelled Orders",
    cancelledAmount: "Cancelled Sales Amount",
    preferredLanguage: "Preferred Language",
    switchLanguage: "Switch Language",
    currency: "SAR",
    arabic: "العربية",
    english: "English",
    bengali: "বাংলা",
    searchProduct: "Search product name or barcode...",
    filterByStatus: "Filter by status",
    all: "All",
    saveChanges: "Save Changes",
    confirm: "Confirm",
    cancel: "Cancel",
    success: "Operation completed successfully",
    error: "An error occurred",
  },
  bn: {
    appName: "দেওয়ানিয়া মেধাল রেস্টুরেন্ট বিক্রয় ব্যবস্থা",
    appSubtitle: "বহুভাষিক বিক্রয়, পণ্য মজুত ও গণনা ব্যবস্থাপনা",
    login: "লগইন করুন",
    logout: "লগআউট",
    welcome: "স্বাগতম",
    role: "দায়িত্ব",
    admin: "ম্যানেজমেন্ট (মালিক)",
    worker: "কর্মী / ক্যাশিয়ার",
    username: "ইউজারনেম",
    password: "পাসওয়ার্ড",
    fullName: "পূর্ণ নাম",
    phone: "মোবাইল নম্বর",
    loginAsWorker: "কর্মী লগইন (পয়েন্ট অব সেল ও গণনা)",
    loginAsAdmin: "মালিক/ম্যানেজার লগইন (লাভ ও রিপোর্ট)",
    enterUsername: "ইউজারনেম দিন",
    enterPassword: "পাসওয়ার্ড দিন",
    loginButton: "প্রবেশ করুন",
    portalTitleWorker: "কর্মী ও ক্যাশিয়ার পোর্টাল",
    portalTitleAdmin: "ম্যানেজমেন্ট ও আর্থিক নিয়ন্ত্রণ পোর্টাল",
    dashboard: "ড্যাশবোর্ড",
    posCashier: "বিক্রয় কাউন্টার (POS)",
    productsAndStock: "পণ্য ও মজুত ব্যবস্থাপনা",
    inventoryStocktake: "মজুত পণ্য গণনা (দৈনিক / সাপ্তাহিক)",
    ordersAndSales: "বিক্রয় হিসাব ও রসিদ",
    staffManagement: "কর্মী একাউন্ট তৈরি",
    reportsAndProfits: "মোট লাভ, খরচ ও ভ্যাট",
    notifications: "নোটিফিকেশন ও বার্তা",
    totalSales: "মোট বিক্রয়",
    totalCost: "মোট খরচ / ক্রয়মূল্য",
    totalTax: "মোট ভ্যাট (১৫%)",
    netProfit: "নিট লাভ",
    profitMargin: "লাভের হার",
    completedOrders: "সফল বিক্রয়",
    cancelledOrders: "বাতিলকৃত অর্ডার",
    lowStockItems: "কম মজুত থাকা পণ্য",
    totalProducts: "মোট পণ্য সংখ্যা",
    orderNumber: "চালান / ইনভয়েস নং",
    customerNumber: "গ্রাহক নং (যেমন ৫৫)",
    customerName: "গ্রাহকের নাম",
    customerPhone: "গ্রাহকের ফোন নম্বর",
    itemsPurchased: "ক্রয়কৃত পণ্যসমূহ",
    quantity: "পরিমাণ",
    price: "বিক্রয় মূল্য",
    cost: "ক্রয় খরচ",
    tax: "ভ্যাট",
    grandTotal: "সর্বমোট টাকা",
    paymentMethod: "মূল্য পরিশোধ পদ্ধতি",
    cash: "নগদ (Cash)",
    card: "কার্ড (Mada/Card)",
    online: "অনলাইন স্থানান্তর",
    credit: "বাকি",
    status: "অবস্থা",
    completed: "সম্পন্ন",
    cancelled: "বাতিলকৃত",
    actions: "পদক্ষেপ",
    cancelOrder: "অর্ডার বাতিল করুন",
    cancelReason: "বাতিলের কারণ",
    submitSale: "বিক্রয় সম্পন্ন ও রসিদ প্রিন্ট করুন",
    addToCart: "তালিকায় যোগ করুন",
    cart: "বিক্রয় ঝুড়ি",
    emptyCart: "ঝুড়ি খালি, পণ্য নির্বাচন করুন",
    productImage: "পণ্যের ছবি",
    uploadImage: "ছবি আপলোড করুন",
    sku: "পণ্য কোড (SKU)",
    barcode: "বারকোড",
    nameAr: "নাম (আরবি)",
    nameEn: "নাম (ইংরেজি)",
    nameBn: "নাম (বাংলা)",
    sellingPrice: "বিক্রয় মূল্য",
    costPrice: "ক্রয় খরচ",
    taxRate: "ভ্যাট হার %",
    stockQuantity: "বর্তমান মজুত",
    stockRange: "মজুত সীমা (কম থেকে বেশি)",
    minStock: "সর্বনিম্ন সতর্কতা সীমা",
    maxStock: "সর্বোচ্চ লক্ষ্যমাত্রা",
    addProduct: "নতুন পণ্য যোগ করুন",
    editProduct: "পণ্য সম্পাদনা",
    deleteProduct: "পণ্য মুছে ফেলুন",
    stocktakeTitle: "মজুত গণনা সেশন",
    newStocktake: "নতুন গণনা শুরু করুন",
    cycleType: "গণনার প্রকার",
    daily: "দৈনিক",
    weekly: "সাপ্তাহিক",
    adhoc: "তাৎক্ষণিক",
    sendStocktakeAlert: "কর্মীদের গণনা শুরু করতে বার্তা পাঠান",
    stocktakePromptWorker: "এখনই পণ্য গণনা করুন এবং সঠিক সংখ্যা লিপিবদ্ধ করুন",
    expectedQty: "সিস্টেমে মজুত সংখ্যা",
    actualCount: "বাস্তবে গণনাকৃত সংখ্যা",
    difference: "পার্থক্য (কম / বেশি)",
    costVariance: "আর্থিক ক্ষতির পরিমাণ",
    completeStocktake: "গণনা অনুমোদন ও মজুত আপডেট করুন",
    applyToStock: "সরাসরি পণ্য মজুত পরিবর্তন করুন",
    sendNotification: "জরুরি নোটিফিকেশন পাঠান",
    sendToAll: "সকল কর্মী",
    sendToWorker: "নির্দিষ্ট কর্মী",
    title: "নোটিফিকেশনের শিরোনাম",
    message: "বার্তা বিবরণ",
    sendNow: "বার্তা পাঠান",
    staffPerformance: "কর্মীদের বিক্রয় পারফরম্যান্স",
    salesCount: "মোট বিক্রয় সংখ্যা",
    salesAmount: "মোট বিক্রয় মূল্য",
    cancelledCount: "বাতিলকৃত অর্ডার সংখ্যা",
    cancelledAmount: "বাতিলকৃত বিক্রয়ের টাকা",
    preferredLanguage: "পছন্দের ভাষা",
    switchLanguage: "ভাষা পরিবর্তন",
    currency: "SAR (রিয়াল)",
    arabic: "العربية",
    english: "English",
    bengali: "বাংলা",
    searchProduct: "পণ্যের নাম বা বারকোড দিয়ে খুঁজুন...",
    filterByStatus: "অবস্থা ফিল্টার",
    all: "সকল",
    saveChanges: "সংরক্ষণ করুন",
    confirm: "নিশ্চিত করুন",
    cancel: "বাতিল",
    success: "সফলভাবে সম্পন্ন হয়েছে",
    error: "ত্রুটি ঘটেছে",
  },
};
