export { ONE_YEAR_MS } from "@shared/const";
export const startLogin = () => { window.location.href = "/login"; };
