import React, { useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  Users,
  UserPlus,
  Shield,
  KeyRound,
  Globe,
  Phone,
  CheckCircle2,
  XCircle,
  Pencil,
  Lock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function StaffPage() {
  const { t, language } = useLanguage();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<any>(null);
  const [viewingSalesStaff, setViewingSalesStaff] = useState<any>(null);

  // New staff inputs
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<"worker" | "admin">("worker");
  const [prefLang, setPrefLang] = useState<"ar" | "en" | "bn">("ar");
  const [phone, setPhone] = useState("");

  const staffQuery = trpc.staff.list.useQuery();
  const performanceQuery = trpc.staff.performance.useQuery();
  const salesDetailsQuery = trpc.staff.salesDetails.useQuery(
    { staffId: viewingSalesStaff?.id ?? 0 },
    { enabled: !!viewingSalesStaff }
  );
  const utils = trpc.useUtils();

  const friendlyError = (message: string) => {
    if (message.includes("username") && (message.includes("too_small") || message.includes("Too small"))) return "اسم المستخدم يجب أن يكون حرفين على الأقل";
    if (message.includes("password") && (message.includes("too_small") || message.includes("Too small"))) return "كلمة المرور يجب أن تكون 4 أحرف على الأقل";
    return message || t.error;
  };

  const createStaffMutation = trpc.staff.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء حساب العامل/الإداري بنجاح مع اسم المستخدم وكلمة السر!");
      setCreateDialogOpen(false);
      resetForm();
      utils.staff.list.invalidate();
      utils.staff.performance.invalidate();
    },
    onError: (err) => toast.error(friendlyError(err.message)),
  });

  const updateStaffMutation = trpc.staff.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات الحساب بنجاح!");
      setEditingStaff(null);
      resetForm();
      utils.staff.list.invalidate();
      utils.staff.performance.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const deleteStaffMutation = trpc.staff.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الحساب بنجاح");
      utils.staff.list.invalidate();
      utils.staff.performance.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const resetForm = () => {
    setUsername("");
    setPassword("");
    setFullName("");
    setRole("worker");
    setPrefLang("ar");
    setPhone("");
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createStaffMutation.mutate({
      username: username.trim(),
      password: password.trim(),
      fullName: fullName.trim(),
      role,
      preferredLanguage: prefLang,
      phone: phone.trim() || undefined,
    });
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStaff) return;
    updateStaffMutation.mutate({
      id: editingStaff.id,
      fullName: fullName.trim() || undefined,
      role,
      preferredLanguage: prefLang,
      phone: phone.trim() || undefined,
      password: password.trim() ? password.trim() : undefined,
    });
  };

  const openEdit = (st: any) => {
    setEditingStaff(st);
    setFullName(st.fullName);
    setRole(st.role);
    setPrefLang(st.preferredLanguage);
    setPhone(st.phone || "");
    setPassword("");
  };

  const handleDelete = (st: any) => {
    if (window.confirm(`هل أنت متأكد من حذف حساب ${st.fullName}؟ لا يمكن التراجع عن هذا الإجراء.`)) {
      deleteStaffMutation.mutate({ id: st.id });
    }
  };

  const performanceMap = React.useMemo(() => {
    const map = new Map();
    performanceQuery.data?.forEach((p) => map.set(p.staffId, p));
    return map;
  }, [performanceQuery.data]);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="admin" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <Users className="w-6 h-6 text-purple-600" />
              <span>{t.staffManagement}</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              إضافة حسابات العمال: تحديد اسم المستخدم، كلمة السر، الاسم، لغة الواجهة، ومتابعة مبيعات وإلغاءات كل عامل
            </p>
          </div>

          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-purple-600 hover:bg-purple-500 text-white font-bold gap-2 text-xs rounded-xl shadow-md shadow-purple-600/20">
                <UserPlus className="w-4 h-4" />
                إضافة عامل أو إداري جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md bg-white rounded-2xl">
              <DialogHeader>
                <DialogTitle className="text-lg font-bold">
                  إنشاء حساب جديد (يوزر وباسورد واسم)
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleCreate} className="space-y-4 pt-2">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.fullName} *</Label>
                  <Input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="مثال: خالد الشهري"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">{t.username} *</Label>
                    <Input
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="أدخل اسم المستخدم (حرفان على الأقل)"
                      minLength={2}
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">{t.password} *</Label>
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">{t.role}</Label>
                    <div className="flex gap-1">
                      <Button
                        type="button"
                        size="sm"
                        variant={role === "worker" ? "default" : "outline"}
                        onClick={() => setRole("worker")}
                        className="flex-1 text-xs"
                      >
                        {t.worker}
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant={role === "admin" ? "default" : "outline"}
                        onClick={() => setRole("admin")}
                        className="flex-1 text-xs"
                      >
                        {t.admin}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">{t.preferredLanguage}</Label>
                    <div className="flex gap-1">
                      <Button
                        type="button"
                        size="sm"
                        variant={prefLang === "ar" ? "default" : "outline"}
                        onClick={() => setPrefLang("ar")}
                        className="flex-1 text-xs"
                      >
                        عربي
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant={prefLang === "en" ? "default" : "outline"}
                        onClick={() => setPrefLang("en")}
                        className="flex-1 text-xs"
                      >
                        EN
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant={prefLang === "bn" ? "default" : "outline"}
                        onClick={() => setPrefLang("bn")}
                        className="flex-1 text-xs"
                      >
                        বাংলা
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.phone}</Label>
                  <Input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="05xxxxxxxx"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={createStaffMutation.isPending}
                  className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold"
                >
                  {createStaffMutation.isPending ? "جاري الإنشاء..." : "إنشاء الحساب الآن"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Staff Table with Performance Metrics */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right">
              <thead className="bg-slate-50 text-slate-600 border-b">
                <tr>
                  <th className="py-3 px-4">اسم الموظف</th>
                  <th className="py-3 px-4">اسم المستخدم (اليوزر)</th>
                  <th className="py-3 px-4">الصلاحية</th>
                  <th className="py-3 px-4">اللغة المفضلة</th>
                  <th className="py-3 px-4">إجمالي مبيعات العامل</th>
                  <th className="py-3 px-4">طلبات مكتملة</th>
                  <th className="py-3 px-4">طلبات ملغاة</th>
                  <th className="py-3 px-4">آخر دخول</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {staffQuery.data?.map((st) => {
                  const perf = performanceMap.get(st.id);
                  return (
                    <tr key={st.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {st.fullName}
                        {st.phone && (
                          <div className="text-[10px] text-slate-400 font-normal">
                            {st.phone}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono font-semibold text-purple-700">
                        @{st.username}
                      </td>

                      <td className="py-3.5 px-4">
                        <Badge
                          variant={st.role === "admin" ? "default" : "secondary"}
                          className="text-[10px]"
                        >
                          {st.role === "admin" ? t.admin : t.worker}
                        </Badge>
                      </td>

                      <td className="py-3.5 px-4">
                        <Badge variant="outline" className="text-[10px]">
                          {st.preferredLanguage === "ar"
                            ? "🇸🇦 العربية"
                            : st.preferredLanguage === "bn"
                            ? "🇧🇩 বাংলা"
                            : "🇬🇧 English"}
                        </Badge>
                      </td>

                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {perf?.completedSalesAmount?.toFixed(2) || "0.00"} {t.currency}
                      </td>

                      <td className="py-3.5 px-4 font-semibold text-emerald-600">
                        {perf?.completedSalesCount || 0}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`font-semibold ${
                            perf?.cancelledOrdersCount ? "text-red-500" : "text-slate-400"
                          }`}
                        >
                          {perf?.cancelledOrdersCount || 0}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">
                        {st.lastLoginAt
                          ? new Date(st.lastLoginAt).toLocaleDateString()
                          : "لم يسجل بعد"}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => openEdit(st)}
                            className="text-xs h-7 px-2 text-purple-600 hover:bg-purple-50"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            تعديل وصلاحيات
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setViewingSalesStaff(st)}
                            className="text-xs h-7 px-2 text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            المبيعات
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(st)}
                            disabled={deleteStaffMutation.isPending}
                            className="text-xs h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            حذف
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <Dialog open={!!viewingSalesStaff} onOpenChange={(open) => !open && setViewingSalesStaff(null)}>
          <DialogContent className="max-w-2xl bg-white rounded-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold">مبيعات العامل: {viewingSalesStaff?.fullName}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              {salesDetailsQuery.isLoading ? (
                <div className="py-8 text-center text-slate-500">جاري تحميل الطلبات...</div>
              ) : salesDetailsQuery.data?.length ? (
                salesDetailsQuery.data.map(({ order, items }) => (
                  <div key={order.id} className="rounded-xl border border-slate-200 p-3 bg-slate-50">
                    <div className="flex items-center justify-between mb-2 text-xs">
                      <span className="font-bold">فاتورة {order.orderNumber} · زبون #{order.customerNumber}</span>
                      <Badge className={order.status === "cancelled" ? "bg-red-500 text-white" : "bg-emerald-600 text-white"}>{order.status === "cancelled" ? "ملغاة" : "مكتملة"}</Badge>
                    </div>
                    <div className="space-y-1 text-xs">
                      {items.map((item) => (
                        <div key={item.id} className="flex justify-between border-b border-slate-200 last:border-0 py-1">
                          <span>{item.productName} × {item.quantity}</span>
                          <span className="font-semibold">{item.lineTotal} {t.currency}</span>
                        </div>
                      ))}
                    </div>
                    <div className="text-left text-xs font-bold mt-2">الإجمالي: {order.grandTotal} {t.currency}</div>
                  </div>
                ))
              ) : (
                <div className="py-8 text-center text-slate-500">لا توجد طلبات لهذا العامل</div>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Staff Dialog */}
        <Dialog
          open={!!editingStaff}
          onOpenChange={(open) => !open && setEditingStaff(null)}
        >
          <DialogContent className="max-w-md bg-white rounded-2xl">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold">
                تعديل بيانات الحساب (@{editingStaff?.username})
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleUpdate} className="space-y-4 pt-2">
              <div className="space-y-1">
                <Label className="text-xs font-semibold">{t.fullName}</Label>
                <Input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs font-semibold">
                  كلمة السر الجديدة (اتركه فارغاً للإبقاء على الحالية)
                </Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.role}</Label>
                  <div className="flex gap-1">
                    <Button
                      type="button"
                      size="sm"
                      variant={role === "worker" ? "default" : "outline"}
                      onClick={() => setRole("worker")}
                      className="flex-1 text-xs"
                    >
                      عامل
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={role === "admin" ? "default" : "outline"}
                      onClick={() => setRole("admin")}
                      className="flex-1 text-xs"
                    >
                      إدارة
                    </Button>
                  </div>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs font-semibold">اللغة المفضلة</Label>
                  <div className="flex gap-1">
                    <Button
                      type="button"
                      size="sm"
                      variant={prefLang === "ar" ? "default" : "outline"}
                      onClick={() => setPrefLang("ar")}
                      className="flex-1 text-xs"
                    >
                      عربي
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={prefLang === "en" ? "default" : "outline"}
                      onClick={() => setPrefLang("en")}
                      className="flex-1 text-xs"
                    >
                      EN
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={prefLang === "bn" ? "default" : "outline"}
                      onClick={() => setPrefLang("bn")}
                      className="flex-1 text-xs"
                    >
                      বাংলা
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs font-semibold">{t.phone}</Label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="05xxxxxxxx"
                />
              </div>

              <Button
                type="submit"
                disabled={updateStaffMutation.isPending}
                className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold"
              >
                {updateStaffMutation.isPending ? "جاري الحفظ..." : "حفظ التغييرات"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
