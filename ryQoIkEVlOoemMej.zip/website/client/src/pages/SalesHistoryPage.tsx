import React, { useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  Receipt,
  Search,
  Eye,
  XCircle,
  CheckCircle,
  User,
  Phone,
  Calendar,
  AlertCircle,
  FileText,
  Printer,
  Ban,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function SalesHistoryPage() {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState("");
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [orderToCancel, setOrderToCancel] = useState<any>(null);
  const [cancelReason, setCancelReason] = useState("إرجاع الزبون للبضاعة");

  const salesQuery = trpc.sales.list.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: false, staleTime: 10000 });
  const staffQuery = trpc.staff.list.useQuery(undefined, { refetchInterval: 30000, refetchIntervalInBackground: false, staleTime: 20000 });
  const utils = trpc.useUtils();

  const detailsQuery = trpc.sales.getDetails.useQuery(
    { id: selectedOrderId! },
    { enabled: !!selectedOrderId }
  );

  const cancelMutation = trpc.sales.cancelOrder.useMutation({
    onSuccess: () => {
      toast.success("تم إلغاء الطلب واسترجاع الكميات للمخزون بنجاح");
      setCancelModalOpen(false);
      utils.sales.list.invalidate();
      utils.sales.getDetails.invalidate();
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
      utils.staff.performance.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const staffMap = React.useMemo(() => {
    const map = new Map();
    staffQuery.data?.forEach((s) => map.set(s.id, s));
    return map;
  }, [staffQuery.data]);

  const filteredOrders = salesQuery.data?.filter((ord) => {
    const text = `${ord.orderNumber} ${ord.customerNumber} ${ord.customerName || ""} ${ord.notes || ""}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  const handleOpenCancel = (ord: any) => {
    setOrderToCancel(ord);
    setCancelReason("طلب العميل استرجاع الفاتورة");
    setCancelModalOpen(true);
  };

  const handleConfirmCancel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderToCancel) return;
    cancelMutation.mutate({
      orderId: orderToCancel.id,
      reason: cancelReason,
    });
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="admin" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <Receipt className="w-6 h-6 text-blue-600" />
              <span>{t.ordersAndSales}</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              سجل تفصيلي: رقم الزبون (مثل 55)، الأصناف المشتراة، التكلفة، وإلغاء الطلبات
            </p>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            <Input
              placeholder="بحث برقم الزبون (مثلا 55) أو الفاتورة..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-9 bg-slate-50 border-slate-200 text-xs h-9"
            />
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right">
              <thead className="bg-slate-50 text-slate-600 border-b">
                <tr>
                  <th className="py-3 px-4">{t.orderNumber}</th>
                  <th className="py-3 px-4">{t.customerNumber}</th>
                  <th className="py-3 px-4">اسم الزبون</th>
                  <th className="py-3 px-4">البائع (العامل)</th>
                  <th className="py-3 px-4">المجموع والتكلفة</th>
                  <th className="py-3 px-4">{t.netProfit}</th>
                  <th className="py-3 px-4">{t.status}</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders?.map((ord) => {
                  const seller = staffMap.get(ord.sellerStaffId);
                  const isCancelled = ord.status === "cancelled";

                  return (
                    <tr
                      key={ord.id}
                      className={`transition-colors ${
                        isCancelled ? "bg-red-50/40" : "hover:bg-slate-50/70"
                      }`}
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {ord.orderNumber}
                        <div className="text-[10px] text-slate-400 font-sans">
                          {new Date(ord.createdAt).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <Badge
                          variant="outline"
                          className="font-bold text-xs border-emerald-600 text-emerald-800 bg-emerald-50"
                        >
                          زبون #{ord.customerNumber}
                        </Badge>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-800">
                          {ord.customerName || "-"}
                        </div>
                        {ord.customerPhone && (
                          <div className="text-[10px] text-slate-400">
                            {ord.customerPhone}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-800">
                          {seller?.fullName || `عامل #${ord.sellerStaffId}`}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-black text-slate-900">
                          {parseFloat(ord.grandTotal).toFixed(2)} {t.currency}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          تكلفة: {parseFloat(ord.totalCost).toFixed(2)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`font-bold ${isCancelled ? "line-through text-slate-400" : "text-emerald-700"}`}>
                          +{parseFloat(ord.netProfit).toFixed(2)} {t.currency}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <Badge
                          className={`text-[10px] ${
                            isCancelled
                              ? "bg-red-500 text-white"
                              : "bg-emerald-600 text-white"
                          }`}
                        >
                          {isCancelled ? "ملغي ومسترجع" : "مكتمل"}
                        </Badge>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedOrderId(ord.id)}
                            className="text-xs h-7 px-2 gap-1 text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            التفاصيل
                          </Button>

                          {!isCancelled && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleOpenCancel(ord)}
                              className="text-xs h-7 px-2 text-red-500 hover:bg-red-50"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              إلغاء
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Invoice Item Details Dialog (الزبون رقم 55 اشترى كيت وكيت) */}
        <Dialog
          open={!!selectedOrderId}
          onOpenChange={(open) => !open && setSelectedOrderId(null)}
        >
          <DialogContent className="max-w-lg bg-white rounded-2xl">
            <DialogHeader className="border-b pb-3">
              <DialogTitle className="text-lg font-bold flex items-center justify-between">
                <span>تفاصيل المشتريات للزبون</span>
                <Badge className="bg-emerald-600 text-white text-xs">
                  زبون #{detailsQuery.data?.order.customerNumber}
                </Badge>
              </DialogTitle>
            </DialogHeader>

            {detailsQuery.data && (
              <div className="space-y-4 pt-2 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl space-y-1.5 border">
                  <div className="flex justify-between">
                    <span className="text-slate-500">رقم الفاتورة:</span>
                    <span className="font-bold font-mono">
                      {detailsQuery.data.order.orderNumber}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">اسم العميل:</span>
                    <span className="font-semibold">
                      {detailsQuery.data.order.customerName || "زبون نقدي"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">ملاحظات الطلب:</span>
                    <span className="text-slate-700 italic">
                      {detailsQuery.data.order.notes || "لا يوجد"}
                    </span>
                  </div>
                </div>

                {/* Items Breakdown */}
                <div>
                  <h4 className="font-bold text-slate-800 mb-2">
                    المنتجات المشتراة (كيت وكيت):
                  </h4>
                  <div className="space-y-2">
                    {detailsQuery.data.items.map((it) => (
                      <div
                        key={it.id}
                        className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-slate-900">
                            {it.productName}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            الكمية: {it.quantity} × {it.unitSellingPrice} {t.currency}
                          </div>
                        </div>

                        <div className="text-left">
                          <div className="font-bold text-slate-900">
                            {it.lineTotal} {t.currency}
                          </div>
                          <div className="text-[10px] text-emerald-600">
                            ربح: +{it.lineProfit}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Totals */}
                <div className="border-t pt-3 space-y-1">
                  <div className="flex justify-between text-slate-600">
                    <span>المجموع الفرعي:</span>
                    <span>{detailsQuery.data.order.subtotal} {t.currency}</span>
                  </div>
                  <div className="flex justify-between text-base font-extrabold text-slate-900 border-t pt-1">
                    <span>الإجمالي النهائي:</span>
                    <span className="text-emerald-700">
                      {detailsQuery.data.order.grandTotal} {t.currency}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Cancellation Reason Dialog */}
        <Dialog open={cancelModalOpen} onOpenChange={setCancelModalOpen}>
          <DialogContent className="max-w-md bg-white rounded-2xl">
            <DialogHeader>
              <DialogTitle className="text-base font-bold text-red-600 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                إلغاء الطلب واسترجاع البضاعة للمخزون
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleConfirmCancel} className="space-y-4 pt-2">
              <p className="text-xs text-slate-600">
                سيتم إلغاء فاتورة الزبون رقم #{orderToCancel?.customerNumber} وإعادة كامل كميات المنتجات إلى المخزن تلقائياً.
              </p>

              <div className="space-y-1">
                <Label className="text-xs font-semibold">سبب الإلغاء</Label>
                <Input
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  placeholder="مثال: رغبة الزبون، خلل بالمنتج..."
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={cancelMutation.isPending}
                className="w-full bg-red-600 hover:bg-red-500 text-white font-bold text-xs"
              >
                {cancelMutation.isPending ? "جاري الإلغاء..." : "تأكيد إلغاء الطلب"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
