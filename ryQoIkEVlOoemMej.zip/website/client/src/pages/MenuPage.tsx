import React, { useMemo, useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import { Search, Package, ShoppingCart, Plus, Settings2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function MenuPage({ portal = "worker" }: { portal?: "worker" | "admin" }) {
  const { language, t } = useLanguage();
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const productsQuery = trpc.products.list.useQuery();
  const sectionsQuery = trpc.menuSections.list.useQuery();
  const products = productsQuery.data || [];
  const categories = useMemo(() => Array.from(new Set(products.map((p) => p.category))), [products]);
  const sectionName = (slug: string) => {
    const section = (sectionsQuery.data || []).find((item) => item.slug === slug);
    return section ? (language === "en" ? section.nameEn : language === "bn" ? section.nameBn : section.nameAr) : slug;
  };
  const filtered = products.filter((p) => {
    const name = language === "en" ? p.nameEn : language === "bn" ? p.nameBn : p.nameAr;
    return (category === "all" || p.category === category) && `${name} ${p.sku}`.toLowerCase().includes(search.toLowerCase());
  });

  return <div className="min-h-screen bg-slate-100">
    <HeaderNav portal={portal} />
    <main className="max-w-7xl mx-auto p-4 sm:p-6 space-y-5">
      <section className="rounded-3xl bg-gradient-to-l from-slate-950 via-slate-900 to-emerald-950 text-white p-6 sm:p-8 flex flex-col md:flex-row justify-between gap-5">
        <div><p className="text-emerald-300 text-xs font-bold mb-2">مطعم ديوانية مداهل</p><h1 className="text-3xl font-black">المنيو</h1><p className="text-slate-300 text-sm mt-2">تصفح الأصناف والأسعار بسرعة، وإدارة المنيو تتم من صفحة المنتجات في الإدارة.</p></div>
        <div className="flex gap-2 items-start"><Button onClick={() => setLocation("/workers")} className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold gap-2"><ShoppingCart className="w-4 h-4" /> فتح الطلبات</Button>{portal === "admin" ? <Button onClick={() => setLocation("/products")} variant="outline" className="border-white/30 bg-white/10 text-white hover:bg-white/20 gap-2"><Settings2 className="w-4 h-4" /> إدارة المنتجات</Button> : null}</div>
      </section>
      <div className="bg-white rounded-2xl border p-3 flex flex-col sm:flex-row gap-3"><div className="relative flex-1"><Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن صنف أو رمز المنتج" className="pr-9" /></div><div className="flex gap-2 overflow-x-auto"><Button size="sm" variant={category === "all" ? "default" : "outline"} onClick={() => setCategory("all")}>الكل</Button>{categories.map((c) => <Button key={c} size="sm" variant={category === c ? "default" : "outline"} onClick={() => setCategory(c)}>{sectionName(c)}</Button>)}</div></div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">{filtered.map((p) => { const name = language === "en" ? p.nameEn : language === "bn" ? p.nameBn : p.nameAr; return <Card key={p.id} className="overflow-hidden rounded-2xl border-slate-200"><div className="aspect-square bg-slate-100">{p.imageUrl ? <img src={p.imageUrl} alt={name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Package className="w-12 h-12 text-slate-300" /></div>}</div><CardContent className="p-3"><div className="flex justify-between gap-2"><div><p className="font-bold text-sm text-slate-900">{name}</p><p className="text-xs text-slate-500 mt-1">{sectionName(p.category)}</p></div><Badge className="bg-emerald-100 text-emerald-800 h-fit whitespace-nowrap">{parseFloat(p.sellingPrice).toFixed(2)} {t.currency}</Badge></div><Button onClick={() => setLocation("/workers")} size="sm" className="w-full mt-3 gap-2 bg-slate-900 hover:bg-emerald-600"><Plus className="w-3.5 h-3.5" /> إضافة للطلب</Button></CardContent></Card>; })}</div>
    </main>
  </div>;
}
