import React, { useState, useMemo } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CheckCircle,
  CreditCard,
  Banknote,
  Smartphone,
  Printer,
  Package,
  AlertTriangle,
  Loader2,
  Clock3,
  XCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

interface CartItem {
  product: any;
  quantity: number;
}

export default function PosPage() {
  const { language, t } = useLanguage();
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [customerNumber, setCustomerNumber] = useState<number>(55);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card">("card");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [completedOrder, setCompletedOrder] = useState<any>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  const productsQuery = trpc.products.list.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: false, staleTime: 10000 });
  const sectionsQuery = trpc.menuSections.list.useQuery(undefined, { refetchInterval: 30000, refetchIntervalInBackground: false, staleTime: 20000 });
  const dailySummaryQuery = trpc.sales.dailySummary.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: false, staleTime: 10000 });
  const ordersQuery = trpc.sales.list.useQuery(undefined, { refetchInterval: 10000, refetchIntervalInBackground: false, staleTime: 5000 });
  const utils = trpc.useUtils();

  const updateOrderStatusMutation = trpc.sales.updateStatus.useMutation({
    onSuccess: async (_data, variables) => {
      toast.success("تم إلغاء الطلب واستبعاده من الكاش والجرد");
      await Promise.all([ordersQuery.refetch(), dailySummaryQuery.refetch()]);
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
    },
    onError: (err) => toast.error(err.message || "تعذر تحديث حالة الطلب"),
  });

  const checkoutMutation = trpc.sales.checkout.useMutation({
    onSuccess: async (data) => {
      toast.success(`${t.success}: ${data.orderNumber}`);
      const summaryResult = await dailySummaryQuery.refetch();
      setCompletedOrder({
        ...data,
        subtotal,
        orderedAt: new Date().toISOString(),
        paymentMethod,
        items: cart.map((item) => ({
          name: item.product.nameAr,
          quantity: item.quantity,
          total: (parseFloat(item.product.sellingPrice) * item.quantity).toFixed(2),
        })),
        dailySummary: summaryResult.data,
      });
      setShowReceipt(true);
      setCart([]);
      // increment customer number for convenience
      setCustomerNumber((prev) => prev + 1);
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
      utils.sales.list.invalidate();
      dailySummaryQuery.refetch();
    },
    onError: (err) => {
      toast.error(err.message || t.error);
    },
  });

  const filteredProducts = useMemo(() => {
    if (!productsQuery.data) return [];
    return productsQuery.data.filter((prod) => {
      const name =
        language === "bn"
          ? prod.nameBn
          : language === "en"
          ? prod.nameEn
          : prod.nameAr;
      const matchSearch =
        name.toLowerCase().includes(search.toLowerCase()) ||
        prod.sku.toLowerCase().includes(search.toLowerCase()) ||
        (prod.barcode && prod.barcode.includes(search));

      const matchCat =
        selectedCategory === "all" || prod.category === selectedCategory;

      return matchSearch && matchCat;
    });
  }, [productsQuery.data, search, selectedCategory, language]);

  const categories = useMemo(() => {
    if (!productsQuery.data) return [];
    const set = new Set(productsQuery.data.map((p) => p.category));
    return Array.from(set);
  }, [productsQuery.data]);
  const sectionName = (slug: string) => {
    const section = (sectionsQuery.data || []).find((item) => item.slug === slug);
    return section ? (language === "en" ? section.nameEn : language === "bn" ? section.nameBn : section.nameAr) : slug;
  };

  const todayOrders = useMemo(() => {
    const today = new Date().toDateString();
    return (ordersQuery.data || []).filter((order) => new Date(order.createdAt).toDateString() === today);
  }, [ordersQuery.data]);

  const cancelOrder = (orderId: number) => {
    updateOrderStatusMutation.mutate({ orderId, status: "cancelled", reason: "أُلغي من شاشة الطلبات" });
  };

  const addToCart = (product: any) => {
    if (product.stockQuantity <= 0) {
      toast.error(`عذراً، المنتج ${product.nameAr} نفد من المخزون!`);
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stockQuantity) {
          toast.warning(`الكمية المتاحة فقط ${product.stockQuantity}`);
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty > item.product.stockQuantity) {
              toast.warning(`أقصى كمية متاحة هي ${item.product.stockQuantity}`);
              return item;
            }
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Calculations
  const subtotal = cart.reduce((sum, item) => {
    const price = parseFloat(item.product.sellingPrice);
    return sum + price * item.quantity;
  }, 0);

  const totalTax = 0;
  const grandTotal = subtotal;

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error(t.emptyCart);
      return;
    }
    if (!customerNumber || customerNumber <= 0) {
      toast.error("يرجى إدخال رقم الزبون صحيحاً (مثلاً: 55)");
      return;
    }

    checkoutMutation.mutate({
      customerNumber,
      customerName: customerName || `زبون #${customerNumber}`,
      customerPhone,
      paymentMethod,
      items: cart.map((i) => ({
        productId: i.product.id,
        quantity: i.quantity,
      })),
      notes: `فاتورة الزبون رقم ${customerNumber}`,
    });
  };

  const sendReceiptImageToRawBt = (receipt: any) => {
    try {
      const width = 384;
      const lines: string[] = ["مطعم ديوانية مدهال"];
      if (receipt.dailyInventory) {
        lines.push("جرد ومبيعات اليوم", "------------------------------", `التاريخ: ${receipt.date || ""}`, `وقت الطباعة: ${new Date(receipt.printedAt || Date.now()).toLocaleString("ar-SA")}`, `عدد الطلبات: ${receipt.orders || 0}`, `الطلبات الملغاة: ${receipt.cancelledOrders || 0}`, `الكاش: ${receipt.cash || "0.00"} ر.س`, `الشبكة: ${receipt.card || "0.00"} ر.س`, `الإجمالي: ${receipt.total || "0.00"} ر.س`, "------------------------------", "الأصناف المباعة اليوم");
        (receipt.items || []).forEach((item: any) => lines.push(`${item.productName}: ${item.quantity}`));
      } else {
        lines.push("فاتورة مبيعات", "------------------------------", `رقم الفاتورة: ${receipt.orderNumber || ""}`, `رقم الزبون: #${receipt.customerNumber || ""}`, `طريقة الدفع: ${receipt.paymentMethod === "cash" ? "كاش" : "شبكة"}`, `وقت الطلب: ${new Date(receipt.orderedAt || Date.now()).toLocaleString("ar-SA")}`, "------------------------------");
        (receipt.items || []).forEach((item: any) => lines.push(`${item.name}  × ${item.quantity}   ${item.total} ر.س`));
        lines.push("------------------------------", `الإجمالي: ${receipt.total || "0.00"} ر.س`, "شكراً لزيارتكم");
      }
      const lineHeight = 34;
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = lines.length * lineHeight + 28;
      const ctx = canvas.getContext("2d");
      if (!ctx) return false;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, width, canvas.height);
      ctx.fillStyle = "#000"; ctx.font = "bold 23px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; (ctx as any).direction = "rtl";
      lines.forEach((line, index) => ctx.fillText(line, width / 2, 16 + index * lineHeight + lineHeight / 2, width - 18));
      const pixels = ctx.getImageData(0, 0, width, canvas.height).data;
      const bytes: number[] = [0x1b, 0x40, 0x1b, 0x61, 0x01];
      for (let y = 0; y < canvas.height; y += 24) {
        bytes.push(0x1b, 0x2a, 0x21, width & 0xff, (width >> 8) & 0xff);
        for (let x = 0; x < width; x++) for (let band = 0; band < 3; band++) {
          let bits = 0;
          for (let bit = 0; bit < 8; bit++) { const py = y + band * 8 + bit; if (py < canvas.height && pixels[(py * width + x) * 4] < 180) bits |= 1 << (7 - bit); }
          bytes.push(bits);
        }
        bytes.push(0x0a);
      }
      bytes.push(0x0a, 0x0a, 0x0a, 0x1d, 0x56, 0x00);
      let binary = ""; for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.slice(i, i + 8192));
      window.location.href = `rawbt:base64,${btoa(binary)}`;
      toast.success("تم إرسال صورة الفاتورة العربية إلى RawBT");
      return true;
    } catch { return false; }
  };

  const printReceipt = () => {
    if (!completedOrder) return;
    toast.info("جاري إرسال الفاتورة للطباعة...");
    const payload = {
      orderNumber: completedOrder.orderNumber,
      customerNumber: completedOrder.customerNumber,
      subtotal: Number(completedOrder.subtotal || 0).toFixed(2),
      total: completedOrder.grandTotal,
      paymentMethod: completedOrder.paymentMethod,
      orderedAt: completedOrder.orderedAt,
      items: completedOrder.items || [],
    };
    const nativePrinter = (window as any).AndroidPrinter;
    if (nativePrinter?.printReceipt) {
      nativePrinter.printReceipt(JSON.stringify(payload));
      return;
    }
    if (sendReceiptImageToRawBt(payload)) return;
    toast.warning("افتح التطبيق من نسخة APK للطباعة عبر RawBT");
    window.print();
  };

  const printDailyInventory = () => {
    const summary = dailySummaryQuery.data;
    if (!summary) { toast.error("لم يجهز ملخص جرد اليوم بعد"); return; }
    const printedAt = new Date().toISOString();
    const payload = {
      dailyInventory: true,
      printedAt,
      date: summary.date,
      orders: summary.orders,
      cancelledOrders: summary.cancelledOrders || 0,
      cash: Number(summary.cash || 0).toFixed(2),
      card: Number(summary.card || 0).toFixed(2),
      total: Number(summary.total || 0).toFixed(2),
      items: summary.items || [],
    };
    const nativePrinter = (window as any).AndroidPrinter;
    if (nativePrinter?.printReceipt) {
      toast.info("جاري إرسال جرد اليوم للطباعة...");
      nativePrinter.printReceipt(JSON.stringify(payload));
      return;
    }
    if (sendReceiptImageToRawBt(payload)) return;
    toast.warning("افتح التطبيق من نسخة APK للطباعة عبر RawBT");
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="worker" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Side (Catalog & Products) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* Search & Categories Bar */}
          <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:w-72">
              <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
              <Input
                placeholder={t.searchProduct}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9 bg-slate-50 border-slate-200 text-sm"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory("all")}
                className="text-xs rounded-xl"
              >
                {t.all}
              </Button>
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(cat)}
                  className="text-xs rounded-xl whitespace-nowrap"
                >
                  {sectionName(cat)}
                </Button>
              ))}
            </div>
          </div>

          {/* Products Grid with Images */}
          {productsQuery.isLoading ? (
            <div className="flex items-center justify-center py-20 bg-white rounded-2xl border">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border text-center p-4">
              <Package className="w-12 h-12 text-slate-300 mb-2" />
              <p className="text-sm font-semibold text-slate-600">
                لا توجد منتجات مطابقة للبحث
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
              {filteredProducts.map((product) => {
                const name =
                  language === "bn"
                    ? product.nameBn
                    : language === "en"
                    ? product.nameEn
                    : product.nameAr;
                const isLow = product.stockQuantity <= product.minStockAlert;
                const isOut = product.stockQuantity <= 0;
                const selectedQuantity = cart.find((item) => item.product.id === product.id)?.quantity || 0;

                return (
                  <Card
                    key={product.id}
                    onClick={() => !isOut && addToCart(product)}
                    className={`group relative overflow-hidden rounded-2xl border transition-all cursor-pointer hover:shadow-md hover:border-emerald-500 flex flex-col justify-between ${
                      isOut
                        ? "opacity-60 bg-slate-50 cursor-not-allowed"
                        : "bg-white"
                    }`}
                  >
                    {/* Product Image */}
                    <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
                      {product.imageUrl ? (
                        <img
                          src={product.imageUrl}
                          alt={name}
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-300 bg-slate-50">
                          <Package className="w-12 h-12" />
                        </div>
                      )}

                      {/* Stock Badge */}
                      <div className="absolute top-2 right-2">
                        {isOut ? (
                          <Badge variant="destructive" className="text-[10px]">
                            نفد المخزون
                          </Badge>
                        ) : isLow ? (
                          <Badge className="bg-amber-500 hover:bg-amber-600 text-white text-[10px]">
                            باقي: {product.stockQuantity} {product.unit}
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="bg-white/90 backdrop-blur-xs text-[10px]">
                            متوفر: {product.stockQuantity} {product.unit}
                          </Badge>
                        )}
                      </div>

                      {selectedQuantity > 0 && (
                        <>
                          <div className="absolute top-2 left-2 w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg ring-2 ring-white" aria-label="تم اختيار المنتج">
                            <CheckCircle className="w-5 h-5" />
                          </div>
                          <Badge className="absolute top-2 left-12 bg-red-600 hover:bg-red-600 text-white text-xs font-black shadow-lg ring-2 ring-white">
                            {selectedQuantity}
                          </Badge>
                          <button
                            type="button"
                            aria-label="إنقاص كمية المنتج"
                            onClick={(event) => {
                              event.stopPropagation();
                              updateQuantity(product.id, -1);
                            }}
                            className="absolute top-2 left-[4.5rem] w-8 h-8 rounded-full bg-white text-red-600 border-2 border-red-600 flex items-center justify-center shadow-lg hover:bg-red-50 active:scale-95 transition-transform"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>

                    {/* Product Info */}
                    <CardContent className="p-3">
                      <p className="text-xs font-bold text-slate-800 line-clamp-2 h-8 leading-tight">
                        {name}
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <div>
                          <span className="text-base font-extrabold text-emerald-600">
                            {parseFloat(product.sellingPrice).toFixed(2)}
                          </span>
                          <span className="text-[10px] text-slate-500 mr-1">
                            {t.currency}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Side (Customer Info & Active Cart) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Customer Number Input Card */}
          <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <span className="font-bold text-sm text-slate-800">
                بيانات الزبون والطلب
              </span>
              <Badge variant="outline" className="border-emerald-600 text-emerald-700 font-bold">
                {t.customerNumber}: #{customerNumber}
              </Badge>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-xs font-semibold text-slate-600">
                  {t.customerNumber} (مثال: 55)
                </Label>
                <Input
                  type="number"
                  value={customerNumber}
                  onChange={(e) => setCustomerNumber(parseInt(e.target.value) || 0)}
                  className="font-bold text-base h-9 text-emerald-700 bg-slate-50"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">
                    {t.customerName}
                  </Label>
                  <Input
                    placeholder="اختياري"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="h-8 text-xs bg-slate-50"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">
                    {t.customerPhone}
                  </Label>
                  <Input
                    placeholder="05xxxxxxxx"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="h-8 text-xs bg-slate-50"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Cart Details Card */}
          <Card className="rounded-2xl shadow-xs border border-slate-200 flex-1 flex flex-col justify-between">
            <CardHeader className="p-4 pb-2 border-b flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-emerald-600" />
                <span>{t.cart}</span>
                <span className="text-xs text-slate-400 font-normal">
                  ({cart.length} أصناف)
                </span>
              </CardTitle>
              {cart.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCart([])}
                  className="text-xs text-red-500 hover:text-red-600 h-7 px-2"
                >
                  تفريغ
                </Button>
              )}
            </CardHeader>

            <CardContent className="p-3 flex-1 overflow-y-auto max-h-[340px] space-y-2">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  {t.emptyCart}
                </div>
              ) : (
                cart.map((item) => {
                  const pName =
                    language === "bn"
                      ? item.product.nameBn
                      : language === "en"
                      ? item.product.nameEn
                      : item.product.nameAr;
                  const unitPrice = parseFloat(item.product.sellingPrice);
                  const lineTotal = unitPrice * item.quantity;

                  return (
                    <div
                      key={item.product.id}
                      className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-slate-800 truncate">
                          {pName}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {unitPrice.toFixed(2)} × {item.quantity} ={" "}
                          <span className="font-semibold text-slate-800">
                            {lineTotal.toFixed(2)} {t.currency}
                          </span>
                        </p>
                      </div>

                      <div className="flex items-center gap-1">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(item.product.id, -1)}
                          className="w-6 h-6 rounded-md"
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-6 text-center text-xs font-bold">
                          {item.quantity}
                        </span>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => updateQuantity(item.product.id, 1)}
                          className="w-6 h-6 rounded-md"
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => removeFromCart(item.product.id)}
                          className="w-6 h-6 text-red-500 hover:text-red-600"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
            </CardContent>

            {/* Financial Summary & Payment */}
            <div className="p-4 border-t bg-slate-50/70 rounded-b-2xl space-y-3">
              {/* Payment selector */}
              <div>
                <Label className="text-[11px] font-semibold text-slate-600 mb-1 block">
                  {t.paymentMethod}
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={paymentMethod === "cash" ? "default" : "outline"}
                    onClick={() => setPaymentMethod("cash")}
                    className="text-[11px] h-8 px-1"
                  >
                    <Banknote className="w-3 h-3 ml-1" />
                    {t.cash}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={paymentMethod === "card" ? "default" : "outline"}
                    onClick={() => setPaymentMethod("card")}
                    className="text-[11px] h-8 px-1"
                  >
                    <CreditCard className="w-3 h-3 ml-1" />
                    {t.card}
                  </Button>
                </div>
              </div>

              {/* Price Details */}
              <div className="space-y-1.5 text-xs text-slate-600 border-t pt-2">
                <div className="flex justify-between">
                  <span>المجموع:</span>
                  <span className="font-semibold">{subtotal.toFixed(2)} {t.currency}</span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-slate-900 border-t pt-1">
                  <span>{t.grandTotal}:</span>
                  <span className="text-emerald-700">{grandTotal.toFixed(2)} {t.currency}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <Button
                disabled={cart.length === 0 || checkoutMutation.isPending}
                onClick={handleCheckout}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold h-11 text-sm shadow-md shadow-emerald-600/20 rounded-xl"
              >
                {checkoutMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                ) : (
                  t.submitSale
                )}
              </Button>
            </div>
          </Card>
          <Card className="rounded-2xl border-slate-200 bg-white shadow-sm">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-sm font-black text-slate-900 flex items-center justify-between gap-2">
                <span className="flex items-center gap-2"><Clock3 className="w-4 h-4 text-amber-600" /> طلبات اليوم</span>
                <Badge variant="outline" className="text-[10px]">{todayOrders.length} طلب</Badge>
              </CardTitle>
              <p className="text-[10px] text-slate-500">يظهر وقت كل طلب هنا. إذا أُلغي الطلب اضغط «إلغاء الطلب» حتى يُستبعد من الكاش والجرد.</p>
            </CardHeader>
            <CardContent className="p-4 pt-1 space-y-2">
              {ordersQuery.isLoading ? (
                <div className="py-5 text-center text-xs text-slate-400"><Loader2 className="w-5 h-5 animate-spin mx-auto mb-1" />جاري تحميل الطلبات...</div>
              ) : todayOrders.length === 0 ? (
                <p className="py-4 text-center text-xs text-slate-400">لا توجد طلبات اليوم</p>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {todayOrders.map((order) => {
                    const isCancelled = order.status === "cancelled";
                    return (
                      <div key={order.id} className={`rounded-xl border p-3 ${isCancelled ? "border-red-100 bg-red-50/50" : "border-emerald-100 bg-emerald-50/50"}`}>
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <div className="min-w-0">
                            <p className="font-black text-slate-900 truncate">#{order.orderNumber}</p>
                            <p className="text-[10px] text-slate-500">زبون #{order.customerNumber} · {new Date(order.createdAt).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}</p>
                          </div>
                          <div className="text-left shrink-0">
                            <p className="font-black text-slate-900">{Number(order.grandTotal).toFixed(2)} {t.currency}</p>
                            <p className="text-[10px] text-slate-500">{order.paymentMethod === "cash" ? "كاش" : "شبكة"}</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-2 mt-2">
                          <Badge className={isCancelled ? "bg-red-500 text-white" : "bg-emerald-600 text-white"}>
                            {isCancelled ? "ملغي" : "مكتمل"}
                          </Badge>
                          {!isCancelled && (
                            <Button size="sm" disabled={updateOrderStatusMutation.isPending} onClick={() => cancelOrder(order.id)} variant="outline" className="h-7 text-[10px] border-red-200 text-red-600 hover:bg-red-50"><XCircle className="w-3 h-3 ml-1" />إلغاء الطلب</Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
          <Card className="rounded-2xl border-emerald-100 bg-gradient-to-br from-emerald-50 to-white shadow-sm">
            <CardHeader className="p-4 pb-2"><CardTitle className="text-sm font-black text-emerald-900">ملخص الجرد والمبيعات</CardTitle></CardHeader>
            <CardContent className="p-4 pt-1 space-y-3">
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="rounded-xl bg-white border p-2"><p className="text-[11px] text-slate-500">طلبات اليوم</p><p className="text-xl font-black text-emerald-700">{dailySummaryQuery.data?.orders ?? 0}</p></div>
                <div className="rounded-xl bg-white border p-2"><p className="text-[11px] text-slate-500">طلبات الأسبوع</p><p className="text-xl font-black text-indigo-700">{dailySummaryQuery.data?.weeklyOrders ?? 0}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex justify-between rounded-lg bg-white border px-2 py-1.5"><span>كاش</span><b>{Number(dailySummaryQuery.data?.cash || 0).toFixed(2)} {t.currency}</b></div>
                <div className="flex justify-between rounded-lg bg-white border px-2 py-1.5"><span>شبكة</span><b>{Number(dailySummaryQuery.data?.card || 0).toFixed(2)} {t.currency}</b></div>
              </div>
              <div className="border-t pt-2"><p className="text-[11px] font-bold text-slate-600 mb-1">الكميات المباعة اليوم</p><div className="flex flex-wrap gap-1.5">{(dailySummaryQuery.data?.items || []).length === 0 ? <span className="text-xs text-slate-400">لا توجد مبيعات بعد</span> : dailySummaryQuery.data?.items.map((item) => <Badge key={item.productName} variant="secondary" className="bg-white">{item.productName}: {item.quantity}</Badge>)}</div></div>
              <p className="text-[10px] text-slate-500">الطلبات الملغاة اليوم: <b>{dailySummaryQuery.data?.cancelledOrders ?? 0}</b></p>
              <p className="text-[10px] text-slate-500">آخر جرد: {dailySummaryQuery.data?.lastStocktake?.completedAt ? new Date(dailySummaryQuery.data.lastStocktake.completedAt).toLocaleString("ar-SA") : "لم يسجل بعد"}</p>
              <Button onClick={printDailyInventory} className="w-full mt-1 bg-slate-900 hover:bg-emerald-700 text-white gap-2"><Printer className="w-4 h-4" /> طباعة جرد اليوم</Button>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Invoice Receipt Modal */}
      <Dialog open={showReceipt} onOpenChange={setShowReceipt}>
        <DialogContent className="max-w-md bg-white p-0 rounded-3xl overflow-hidden border-0 shadow-2xl animate-in slide-in-from-bottom-10 fade-in duration-300">
          <div className="p-6">
          <DialogHeader className="text-center pb-2 border-b">
            <div className="mb-2">
              <p className="text-lg font-black text-slate-950">مطعم ديوانية مداهل</p>
              <p className="text-[11px] text-slate-500">فاتورة مبيعات</p>
            </div>
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <CheckCircle className="w-6 h-6" />
            </div>
            <DialogTitle className="text-xl font-bold">
              تفاصيل الطلب
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              {completedOrder?.orderNumber}
            </DialogDescription>
          </DialogHeader>

          <div className="py-3 text-xs space-y-2 border-b">
            <div className="flex justify-between">
              <span className="text-slate-500">{t.customerNumber}:</span>
              <span className="font-bold text-slate-900">
                #{completedOrder?.customerNumber}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">طريقة السداد:</span>
              <span className="font-bold text-slate-900">{completedOrder?.paymentMethod === "cash" ? "كاش" : "شبكة"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">التاريخ والوقت:</span>
              <span>{new Date(completedOrder?.orderedAt || Date.now()).toLocaleString("ar-SA")}</span>
            </div>
          </div>

          <div className="py-3 border-b space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700"><span>الصنف</span><span>الكمية × السعر</span></div>
            {(completedOrder?.items || []).map((item: any, index: number) => <div key={index} className="flex justify-between gap-3 text-xs text-slate-600"><span className="truncate">{item.name}</span><span className="whitespace-nowrap">{item.quantity} × {item.total} {t.currency}</span></div>)}
          </div>

          <div className="py-3 space-y-1 text-xs">
            <div className="flex justify-between text-slate-500 font-semibold">
              <span>{t.grandTotal}:</span>
              <span className="font-extrabold text-base text-emerald-600">
                {completedOrder?.grandTotal} {t.currency}
              </span>
            </div>
          </div>

          <div className="pt-2 text-center">
            <div className="h-12 w-full rounded bg-slate-950 [background-image:repeating-linear-gradient(90deg,#fff_0,#fff_2px,transparent_2px,transparent_5px,#fff_5px,#fff_6px,transparent_6px,transparent_10px)]" aria-label="barcode" />
            <p className="font-mono text-[11px] tracking-[0.25em] mt-1 text-slate-600">{completedOrder?.orderNumber}</p>
          </div>

          <div className="mt-3 rounded-2xl bg-emerald-50 border border-emerald-100 p-3 text-xs space-y-2 animate-in slide-in-from-bottom-3 fade-in duration-500">
            <p className="font-black text-emerald-900">ملخص الجرد والمبيعات</p>
            <div className="grid grid-cols-2 gap-2"><span>طلبات اليوم: <b>{completedOrder?.dailySummary?.orders ?? 0}</b></span><span>طلبات الأسبوع: <b>{completedOrder?.dailySummary?.weeklyOrders ?? 0}</b></span></div>
            <div className="grid grid-cols-2 gap-2"><span>كاش: <b>{Number(completedOrder?.dailySummary?.cash || 0).toFixed(2)}</b></span><span>شبكة: <b>{Number(completedOrder?.dailySummary?.card || 0).toFixed(2)}</b></span></div>
            <p className="text-[10px] text-slate-500">آخر جرد: {completedOrder?.dailySummary?.lastStocktake?.completedAt ? new Date(completedOrder.dailySummary.lastStocktake.completedAt).toLocaleString("ar-SA") : "لم يسجل بعد"}</p>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button
              onClick={printReceipt}
              variant="outline"
              className="flex-1 gap-2 text-xs"
            >
              <Printer className="w-4 h-4" />
              طباعة الفاتورة
            </Button>
            <Button
              onClick={() => setShowReceipt(false)}
              className="flex-1 bg-slate-900 text-white text-xs"
            >
              إغلاق ومتابعة
            </Button>
          </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
