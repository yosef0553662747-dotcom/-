import React, { useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  TrendingUp,
  Receipt,
  DollarSign,
  Package,
  AlertCircle,
  Users,
  Send,
  Calendar,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowUpRight,
  ClipboardCheck,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function DashboardPage() {
  const { t, language } = useLanguage();
  const [, setLocation] = useLocation();

  const [alertDialogOpen, setAlertDialogOpen] = useState(false);
  const [alertTitleAr, setAlertTitleAr] = useState("سوو جرد الآن للمخزون");
  const [alertTitleEn, setAlertTitleEn] = useState("Perform stocktake now");
  const [alertTitleBn, setAlertTitleBn] = useState("এখনই পণ্য গণনা শুরু করুন");
  const [alertMsgAr, setAlertMsgAr] = useState("تنبيه من الإدارة لجميع العمال: يرجى البدء في حصر وجرد الكميات في الرفوف والمستودع");
  const [alertMsgEn, setAlertMsgEn] = useState("Notice from Management: Please conduct the physical inventory stocktake immediately.");
  const [alertMsgBn, setAlertMsgBn] = useState("ম্যানেজমেন্টের জরুরি নোটিশ: অনুগ্রহ করে এখনই সেলফ ও গোডাউনের পণ্য গণনা শুরু করুন।");

  const summaryQuery = trpc.reports.dashboardSummary.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: false, staleTime: 10000 });
  const performanceQuery = trpc.staff.performance.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: false, staleTime: 10000 });
  const productsQuery = trpc.products.list.useQuery(undefined, { refetchInterval: 30000, refetchIntervalInBackground: false, staleTime: 20000 });
  const utils = trpc.useUtils();

  const sendAlertMutation = trpc.notifications.sendAlert.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال الإشعار للعمال بنجاح!");
      setAlertDialogOpen(false);
      utils.notifications.list.invalidate();
    },
    onError: (err) => {
      toast.error(err.message || t.error);
    },
  });

  const handleSendAlert = (e: React.FormEvent) => {
    e.preventDefault();
    sendAlertMutation.mutate({
      titleAr: alertTitleAr,
      titleEn: alertTitleEn,
      titleBn: alertTitleBn,
      messageAr: alertMsgAr,
      messageEn: alertMsgEn,
      messageBn: alertMsgBn,
      type: "stocktake_alert",
    });
  };

  const summary = summaryQuery.data || {
    totalSales: 0,
    totalCost: 0,
    totalTax: 0,
    netProfit: 0,
    completedOrdersCount: 0,
    cancelledOrdersCount: 0,
    totalProductsCount: 0,
    lowStockProductsCount: 0,
  };

  const profitMargin =
    summary.totalSales > 0
      ? ((summary.netProfit / summary.totalSales) * 100).toFixed(1)
      : "0.0";

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="admin" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Welcome and Quick Action Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              {t.portalTitleAdmin}
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              نظرة عامة على الأرباح والمبيعات والجرد
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              تحكم كامل في أسعار التكلفة والبيع، أداء كل عامل، والتحكم الفوري بجلسات الجرد اليومية والأسبوعية وإرسال الإشعارات للعمال.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Quick alert to staff button */}
            <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold gap-2 rounded-xl shadow-lg shadow-amber-500/20">
                  <Send className="w-4 h-4" />
                  {t.sendStocktakeAlert}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg bg-white rounded-2xl">
                <DialogHeader>
                  <DialogTitle className="text-lg font-bold flex items-center gap-2">
                    <Send className="w-5 h-5 text-amber-500" />
                    إرسال إشعار فوري للعمال (مثل: سوو جرد الآن)
                  </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSendAlert} className="space-y-4 pt-2">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">
                      عنوان التنبيه بالعربية
                    </Label>
                    <Input
                      value={alertTitleAr}
                      onChange={(e) => setAlertTitleAr(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">
                      نص الرسالة بالعربية
                    </Label>
                    <Textarea
                      value={alertMsgAr}
                      onChange={(e) => setAlertMsgAr(e.target.value)}
                      rows={2}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <Label className="text-[11px] text-slate-500">العنوان بالإنجليزية (English)</Label>
                      <Input
                        value={alertTitleEn}
                        onChange={(e) => setAlertTitleEn(e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                    <div>
                      <Label className="text-[11px] text-slate-500">العنوان بالبنغالية (বাংলা)</Label>
                      <Input
                        value={alertTitleBn}
                        onChange={(e) => setAlertTitleBn(e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={sendAlertMutation.isPending}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold"
                  >
                    {sendAlertMutation.isPending ? "جاري الإرسال..." : t.sendNow}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>

            <Button
              variant="outline"
              onClick={() => setLocation("/pos")}
              className="border-slate-700 bg-slate-800 text-white hover:bg-slate-700 font-semibold gap-2 rounded-xl"
            >
              <ArrowUpRight className="w-4 h-4" />
              {t.posCashier}
            </Button>
          </div>
        </div>

        {/* Financial KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Total Sales */}
          <Card className="rounded-2xl border-slate-200 shadow-xs hover:shadow-md transition-shadow">
            <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">
                {t.totalSales}
              </span>
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-1">
              <div className="text-2xl font-black text-slate-900">
                {summary.totalSales.toFixed(2)}
                <span className="text-xs font-medium text-slate-500 mr-1.5">
                  {t.currency}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                <span>{summary.completedOrdersCount} طلب مكتمل</span>
              </p>
            </CardContent>
          </Card>

          {/* Net Profit */}
          <Card className="rounded-2xl border-slate-200 shadow-xs hover:shadow-md transition-shadow bg-gradient-to-br from-white to-emerald-50/50">
            <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
              <span className="text-xs font-semibold text-emerald-700">
                {t.netProfit} (الأرباح)
              </span>
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
                <TrendingUp className="w-5 h-5" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-1">
              <div className="text-2xl font-black text-emerald-700">
                {summary.netProfit.toFixed(2)}
                <span className="text-xs font-medium text-emerald-600 mr-1.5">
                  {t.currency}
                </span>
              </div>
              <p className="text-[11px] text-emerald-600 mt-1 font-semibold">
                هامش ربح تقريبي: %{profitMargin}
              </p>
            </CardContent>
          </Card>

          {/* Total Cost */}
          <Card className="rounded-2xl border-slate-200 shadow-xs hover:shadow-md transition-shadow">
            <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">
                {t.totalCost} (التكلفة)
              </span>
              <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Receipt className="w-5 h-5" />
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-1">
              <div className="text-2xl font-black text-slate-900">
                {summary.totalCost.toFixed(2)}
                <span className="text-xs font-medium text-slate-500 mr-1.5">
                  {t.currency}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                سعر شراء البضائع المباعة
              </p>
            </CardContent>
          </Card>

        </div>

        {/* Second Row: Staff Performance & Stock Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Worker Sales Performance Table (كم باع كل عامل وكم طلب ألغي) */}
          <div className="lg:col-span-8 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  <span>{t.staffPerformance}</span>
                </h2>
                <p className="text-xs text-slate-500">
                  متابعة كم باع العامل الفلاني وكم طلبات تم إلغاؤها له
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation("/staff")}
                className="text-xs rounded-xl"
              >
                إدارة الحسابات
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-50 text-slate-600 border-b">
                  <tr>
                    <th className="py-2.5 px-3">العامل / الموظف</th>
                    <th className="py-2.5 px-3">الصلاحية</th>
                    <th className="py-2.5 px-3">الطلبات المكتملة</th>
                    <th className="py-2.5 px-3">إجمالي المبيعات</th>
                    <th className="py-2.5 px-3">الطلبات الملغاة</th>
                    <th className="py-2.5 px-3">مبيعات ملغاة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {performanceQuery.data?.map((st) => (
                    <tr key={st.staffId} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{st.fullName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">@{st.username}</div>
                      </td>
                      <td className="py-3 px-3">
                        <Badge variant={st.role === "admin" ? "default" : "secondary"} className="text-[10px]">
                          {st.role === "admin" ? "إدارة" : "عامل كاشير"}
                        </Badge>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-emerald-600 text-sm">
                          {st.completedSalesCount}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-800">
                        {st.completedSalesAmount.toFixed(2)} {t.currency}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`font-bold ${st.cancelledOrdersCount > 0 ? "text-red-500" : "text-slate-400"}`}>
                          {st.cancelledOrdersCount}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-red-500 font-medium">
                        {st.cancelledSalesAmount.toFixed(2)} {t.currency}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Inventory Stock Range & Status (باقي من كذا لكذا) */}
          <div className="lg:col-span-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Package className="w-5 h-5 text-emerald-600" />
                  <span>حالة المخزون والحدود</span>
                </h2>
                <Badge variant="outline" className="text-xs">
                  {summary.totalProductsCount} أصناف
                </Badge>
              </div>
              <p className="text-xs text-slate-500 mb-4">
                متابعة المنتجات التي اقتربت من النفاد ومستويات المخزون (باقي من كذا إلى كذا)
              </p>

              {/* Product Stock Ranges Mini List */}
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {productsQuery.data?.slice(0, 6).map((p) => {
                  const isLow = p.stockQuantity <= p.minStockAlert;
                  return (
                    <div
                      key={p.id}
                      className="p-2.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-slate-800 truncate">
                          {p.nameAr}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          نطاق الأمان: من {p.minStockAlert} إلى {p.maxStockAlert} {p.unit}
                        </p>
                      </div>

                      <div className="text-left">
                        <Badge
                          className={`text-xs font-bold ${
                            isLow
                              ? "bg-red-500 text-white"
                              : "bg-emerald-100 text-emerald-800 hover:bg-emerald-200"
                          }`}
                        >
                          باقي: {p.stockQuantity} {p.unit}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-2 border-t">
              <Button
                onClick={() => setLocation("/products")}
                variant="default"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl"
              >
                إدارة جميع المنتجات وتعديل الحدود
              </Button>
            </div>
          </div>
        </div>

        {/* Quick Link Cards to Stocktake and Orders */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card
            onClick={() => setLocation("/stocktake")}
            className="p-5 rounded-3xl border-slate-200 cursor-pointer hover:border-amber-400 hover:shadow-md transition-all flex items-center justify-between bg-gradient-to-r from-white to-amber-50/40"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-slate-900 text-base">
                  جلسات الجرد الدوري (اليومي والأسبوعي)
                </h3>
              </div>
              <p className="text-xs text-slate-500">
                تسجيل الكميات الفعلية ومقارنتها بالسيستم وتحديث المخزون بنقرة واحدة
              </p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-amber-600" />
          </Card>

          <Card
            onClick={() => setLocation("/sales")}
            className="p-5 rounded-3xl border-slate-200 cursor-pointer hover:border-blue-400 hover:shadow-md transition-all flex items-center justify-between bg-gradient-to-r from-white to-blue-50/40"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-base">
                  سجل فواتير المبيعات وتفاصيل الزبائن
                </h3>
              </div>
              <p className="text-xs text-slate-500">
                معاينة الزبون رقم 55 وماذا اشترى، مع إمكانية إلغاء الطلبات وإرجاع البضاعة
              </p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-blue-600" />
          </Card>
        </div>
      </main>
    </div>
  );
}
