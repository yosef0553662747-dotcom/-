import React, { useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, ShieldCheck, KeyRound, UserCheck, Globe, Loader2, Code2 } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const { language, setLanguage, t, dir } = useLanguage();
  const [, setLocation] = useLocation();
  const [tabRole, setTabRole] = useState<"worker" | "admin" | "developer">("worker");

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const utils = trpc.useUtils();
  const brandingQuery = trpc.settings.public.useQuery();
  const branding = brandingQuery.data || {};
  const appName = language === "en" ? branding.appNameEn || t.appName : language === "bn" ? branding.appNameBn || t.appName : branding.appNameAr || t.appName;

  const loginMutation = trpc.auth.loginStaff.useMutation({
    onSuccess: async (data) => {
      toast.success(`${t.welcome}: ${data.staff.fullName}`);
      // Wait for the staff cookie to be reflected in auth.me before mounting
      // the protected portal; otherwise the route guard can briefly see null.
      await utils.auth.me.invalidate();
      if (data.staff.role === "admin") {
        setLocation("/admin");
      } else if (data.staff.role === "developer") {
        setLocation("/developer");
      } else {
        setLocation("/workers");
      }
    },
    onError: (err) => {
      toast.error(err.message || t.error);
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    loginMutation.mutate({
      username: username.trim(),
      password: password.trim(),
      expectedRole: tabRole,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white flex flex-col justify-between p-4 sm:p-6 lg:p-8">
      {/* Top Language Bar */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20">
              {branding.logoUrl ? <img src={branding.logoUrl} alt="logo" className="w-full h-full object-cover rounded-xl" /> : <Store className="w-6 h-6" />}
          </div>
          <div>
            <h1 className="font-extrabold text-xl tracking-tight text-white">
              {appName}
            </h1>
            <p className="text-xs text-emerald-400 font-medium">
              Diwaniya Madhhal Restaurant Sales & Inventory
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-800/80 backdrop-blur-xs p-1.5 rounded-xl border border-slate-700">
          <Globe className="w-4 h-4 text-emerald-400 ml-1" />
          <Button
            variant={language === "ar" ? "default" : "ghost"}
            size="sm"
            onClick={() => setLanguage("ar")}
            className="text-xs h-7 px-2.5 rounded-lg"
          >
            العربية
          </Button>
          <Button
            variant={language === "en" ? "default" : "ghost"}
            size="sm"
            onClick={() => setLanguage("en")}
            className="text-xs h-7 px-2.5 rounded-lg"
          >
            English
          </Button>
          <Button
            variant={language === "bn" ? "default" : "ghost"}
            size="sm"
            onClick={() => setLanguage("bn")}
            className="text-xs h-7 px-2.5 rounded-lg"
          >
            বাংলা
          </Button>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="max-w-md w-full mx-auto my-8">
        {branding.introVideoEnabled === "1" && branding.introVideoUrl && <div className="mb-4 rounded-2xl overflow-hidden border border-slate-700 bg-black"><video src={branding.introVideoUrl} controls autoPlay muted playsInline className="w-full max-h-52 object-cover" /><p className="p-2 text-center text-xs text-slate-300">{branding.introTitle || "مرحباً بكم"}</p></div>}
        <Card className="bg-slate-900/90 border-slate-700/80 shadow-2xl backdrop-blur-xl text-white">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
              <KeyRound className="w-6 h-6 text-emerald-400" />
              {t.login}
            </CardTitle>
            <CardDescription className="text-slate-400 text-xs sm:text-sm mt-1">
              {tabRole === "worker" ? t.portalTitleWorker : tabRole === "developer" ? "بوابة المطور وتخصيص البرنامج" : t.portalTitleAdmin}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <Tabs
              value={tabRole}
              onValueChange={(val) => {
                setTabRole(val as "worker" | "admin" | "developer");
                setUsername("");
                setPassword("");
              }}
              className="w-full"
            >
              <TabsList className="grid grid-cols-3 bg-slate-800 p-1 border border-slate-700">
                <TabsTrigger
                  value="worker"
                  className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white font-semibold text-xs sm:text-sm py-2"
                >
                  <UserCheck className="w-4 h-4 mr-1.5 ml-1.5" />
                  {t.worker}
                </TabsTrigger>
                <TabsTrigger
                  value="admin"
                  className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white font-semibold text-xs sm:text-sm py-2"
                >
                  <ShieldCheck className="w-4 h-4 mr-1.5 ml-1.5" />
                  {t.admin}
                </TabsTrigger>
                <TabsTrigger value="developer" className="data-[state=active]:bg-violet-600 data-[state=active]:text-white font-semibold text-xs py-2">
                  <Code2 className="w-4 h-4 mr-1 ml-1" />المطور
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <form onSubmit={handleLogin} className="space-y-4 mt-4">
              <div className="space-y-1.5 text-right">
                <Label className="text-xs font-semibold text-slate-300">
                  {t.username}
                </Label>
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={
                    tabRole === "worker" ? "أدخل اسم المستخدم" : "أدخل اسم المستخدم"
                  }
                  required
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus-visible:ring-emerald-500"
                />
              </div>

              <div className="space-y-1.5 text-right">
                <Label className="text-xs font-semibold text-slate-300">
                  {t.password}
                </Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus-visible:ring-emerald-500"
                />
              </div>

              <Button
                type="submit"
                disabled={loginMutation.isPending}
                className={`w-full py-2.5 font-bold text-white transition-all shadow-md ${
                  tabRole === "admin"
                    ? "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/30"
                    : tabRole === "developer"
                    ? "bg-violet-600 hover:bg-violet-500 shadow-violet-600/30"
                    : "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30"
                }`}
              >
                {loginMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                ) : (
                  t.loginButton
                )}
              </Button>
            </form>

          </CardContent>
        </Card>
      </div>

      {/* Footer info */}
      <div className="text-center text-xs text-slate-500">
        نظام مبيعات مطعم ديوانية مدهال المتكامل، حسابات العمال، الجرد اليومي والأسبوعي، والأرباح والتكاليف
      </div>
    </div>
  );
}
