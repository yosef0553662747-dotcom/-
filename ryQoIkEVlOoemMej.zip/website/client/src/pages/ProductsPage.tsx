import React, { useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  Package,
  Plus,
  Pencil,
  Trash2,
  Upload,
  Image as ImageIcon,
  AlertTriangle,
  Search,
  Filter,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function ProductsPage() {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  // Form fields
  const [sku, setSku] = useState("");
  const [barcode, setBarcode] = useState("");
  const [nameAr, setNameAr] = useState("");
  const [nameEn, setNameEn] = useState("");
  const [nameBn, setNameBn] = useState("");
  const [category, setCategory] = useState("مواد غذائية");
  const [costPrice, setCostPrice] = useState("10.00");
  const [sellingPrice, setSellingPrice] = useState("15.00");
  const [stockQuantity, setStockQuantity] = useState("20");
  const [minStockAlert, setMinStockAlert] = useState("5");
  const [maxStockAlert, setMaxStockAlert] = useState("50");
  const [unit, setUnit] = useState("حبة");
  const [imageUrl, setImageUrl] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);

  const productsQuery = trpc.products.list.useQuery();
  const utils = trpc.useUtils();

  const createMutation = trpc.products.create.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة المنتج بنجاح مع الصورة والبيانات");
      setDialogOpen(false);
      resetForm();
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const updateMutation = trpc.products.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات المنتج بنجاح");
      setDialogOpen(false);
      resetForm();
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const deleteMutation = trpc.products.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المنتج بنجاح");
      utils.products.list.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const uploadImageMutation = trpc.products.uploadImage.useMutation();

  const resetForm = () => {
    setEditingProduct(null);
    setSku(`PRD-${Math.floor(1000 + Math.random() * 9000)}`);
    setBarcode("");
    setNameAr("");
    setNameEn("");
    setNameBn("");
    setCategory("مواد غذائية");
    setCostPrice("10.00");
    setSellingPrice("15.00");
    setStockQuantity("20");
    setMinStockAlert("5");
    setMaxStockAlert("50");
    setUnit("حبة");
    setImageUrl("");
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (p: any) => {
    setEditingProduct(p);
    setSku(p.sku);
    setBarcode(p.barcode || "");
    setNameAr(p.nameAr);
    setNameEn(p.nameEn);
    setNameBn(p.nameBn);
    setCategory(p.category);
    setCostPrice(p.costPrice);
    setSellingPrice(p.sellingPrice);
    setStockQuantity(String(p.stockQuantity));
    setMinStockAlert(String(p.minStockAlert));
    setMaxStockAlert(String(p.maxStockAlert));
    setUnit(p.unit);
    setImageUrl(p.imageUrl || "");
    setDialogOpen(true);
  };

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("يرجى اختيار ملف صورة صالح (PNG, JPG)");
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      toast.error("حجم الصورة كبير جداً. الحد الأقصى 12 ميجابايت");
      e.target.value = "";
      return;
    }

    try {
      setUploadingImage(true);
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const source = new Image();
          source.onload = () => {
            const maxSide = 1200;
            const scale = Math.min(1, maxSide / Math.max(source.width, source.height));
            const canvas = document.createElement("canvas");
            canvas.width = Math.max(1, Math.round(source.width * scale));
            canvas.height = Math.max(1, Math.round(source.height * scale));
            const context = canvas.getContext("2d");
            if (!context) return reject(new Error("تعذر تجهيز الصورة"));
            context.drawImage(source, 0, 0, canvas.width, canvas.height);
            resolve(canvas.toDataURL("image/jpeg", 0.82).split(",")[1] || "");
          };
          source.onerror = () => reject(new Error("تعذر قراءة الصورة"));
          source.src = reader.result as string;
        };
        reader.onerror = () => reject(new Error("تعذر قراءة الصورة"));
        reader.readAsDataURL(file);
      });
      const safeName = `${file.name.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/\.[^.]+$/, "") || "product"}.jpg`;
      const res = await uploadImageMutation.mutateAsync({ filename: safeName, contentType: "image/jpeg", base64Data: base64 });
      setImageUrl(res.url);
      toast.success("تم رفع صورة المنتج بنجاح!");
    } catch (err: any) {
      toast.error(err.message || "فشل رفع الصورة");
    } finally {
      setUploadingImage(false);
      e.target.value = "";
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const data = {
      sku: sku.trim(),
      barcode: barcode.trim() || undefined,
      nameAr: nameAr.trim(),
      nameEn: nameEn.trim(),
      nameBn: nameBn.trim(),
      category: category.trim(),
      imageUrl: imageUrl || undefined,
      costPrice: parseFloat(costPrice) || 0,
      sellingPrice: parseFloat(sellingPrice) || 0,
      taxRate: 0,
      stockQuantity: parseInt(stockQuantity) || 0,
      minStockAlert: parseInt(minStockAlert) || 5,
      maxStockAlert: parseInt(maxStockAlert) || 50,
      unit: unit.trim(),
    };

    if (editingProduct) {
      updateMutation.mutate({ id: editingProduct.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredProducts = productsQuery.data?.filter((p) => {
    const text = `${p.nameAr} ${p.nameEn} ${p.nameBn} ${p.sku} ${p.barcode || ""}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="admin" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Header & Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <Package className="w-6 h-6 text-indigo-600" />
              <span>{t.productsAndStock}</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              إضافة المنتجات بصورها، التحكم في التكلفة، سعر البيع، ونطاقات المخزون (باقي من كذا لكذا)
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <Input
                placeholder={t.searchProduct}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9 bg-slate-50 border-slate-200 text-xs h-9"
              />
            </div>

            <Button
              onClick={openAddDialog}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold gap-2 text-xs h-9 rounded-xl shadow-md shadow-emerald-600/20"
            >
              <Plus className="w-4 h-4" />
              {t.addProduct}
            </Button>
          </div>
        </div>

        {/* Products Table with Images & Stock Ranges */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right">
              <thead className="bg-slate-50 text-slate-600 border-b">
                <tr>
                  <th className="py-3 px-4">الصورة</th>
                  <th className="py-3 px-4">المنتج (عربي / English / বাংলা)</th>
                  <th className="py-3 px-4">التصنيف والرمز</th>
                  <th className="py-3 px-4">{t.costPrice}</th>
                  <th className="py-3 px-4">{t.sellingPrice}</th>
                  <th className="py-3 px-4">المخزون المتوفر</th>
                  <th className="py-3 px-4">نطاق الأمان (الحدود)</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {productsQuery.isLoading ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto text-emerald-600 mb-2" />
                      جاري تحميل المنتجات...
                    </td>
                  </tr>
                ) : filteredProducts?.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      لا توجد منتجات مسجلة حالياً
                    </td>
                  </tr>
                ) : (
                  filteredProducts?.map((product) => {
                    const isLow = product.stockQuantity <= product.minStockAlert;
                    const profitPerUnit =
                      parseFloat(product.sellingPrice) - parseFloat(product.costPrice);

                    return (
                      <tr key={product.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="w-12 h-12 rounded-xl bg-slate-100 border overflow-hidden flex items-center justify-center">
                            {product.imageUrl ? (
                              <img
                                src={product.imageUrl}
                                alt={product.nameAr}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <ImageIcon className="w-5 h-5 text-slate-300" />
                            )}
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{product.nameAr}</div>
                          <div className="text-[11px] text-slate-500">{product.nameEn}</div>
                          <div className="text-[11px] text-emerald-700 font-medium">
                            {product.nameBn}
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <Badge variant="outline" className="text-[10px] mb-1">
                            {product.category}
                          </Badge>
                          <div className="text-[10px] text-slate-400 font-mono">
                            SKU: {product.sku}
                          </div>
                        </td>

                        <td className="py-3 px-4 font-semibold text-slate-600">
                          {parseFloat(product.costPrice).toFixed(2)} {t.currency}
                        </td>

                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">
                            {parseFloat(product.sellingPrice).toFixed(2)} {t.currency}
                          </div>
                          <div className="text-[10px] text-emerald-600 font-medium">
                            ربح: +{profitPerUnit.toFixed(2)}
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <Badge
                            className={`text-xs font-bold ${
                              isLow
                                ? "bg-red-500 text-white animate-pulse"
                                : "bg-emerald-100 text-emerald-800"
                            }`}
                          >
                            باقي: {product.stockQuantity} {product.unit}
                          </Badge>
                        </td>

                        <td className="py-3 px-4 text-slate-500 text-[11px]">
                          من <span className="font-bold text-slate-800">{product.minStockAlert}</span> إلى{" "}
                          <span className="font-bold text-slate-800">{product.maxStockAlert}</span> {product.unit}
                        </td>

                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => openEditDialog(product)}
                              className="w-7 h-7 text-indigo-600 hover:bg-indigo-50"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => {
                                if (confirm("هل أنت متأكد من حذف هذا المنتج؟")) {
                                  deleteMutation.mutate({ id: product.id });
                                }
                              }}
                              className="w-7 h-7 text-red-500 hover:bg-red-50"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Product Add / Edit Modal */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl bg-white rounded-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold">
                {editingProduct ? t.editProduct : t.addProduct}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              {/* Product Image Upload Section */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-4">
                <div className="w-20 h-20 rounded-xl bg-white border border-slate-300 overflow-hidden flex items-center justify-center shrink-0">
                  {imageUrl ? (
                    <img src={imageUrl} alt="preview" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-8 h-8 text-slate-300" />
                  )}
                </div>

                <div className="space-y-1.5 flex-1 w-full text-right">
                  <Label className="text-xs font-bold text-slate-700">
                    {t.productImage} (رفع وحفظ صورة للمنتج)
                  </Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileChange}
                      disabled={uploadingImage}
                      className="text-xs bg-white file:text-xs file:font-semibold file:bg-slate-100 file:border-0 file:rounded-md file:px-2.5 file:py-1"
                    />
                    {uploadingImage && <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />}
                  </div>
                  <Input
                    placeholder="أو رابط صورة مباشر..."
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="text-xs h-8 bg-white"
                  />
                </div>
              </div>

              {/* Multilingual Names */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.nameAr} *</Label>
                  <Input
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                    placeholder="أرز بسمتي فاخر"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.nameEn} *</Label>
                  <Input
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    placeholder="Basmati Rice"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.nameBn} *</Label>
                  <Input
                    value={nameBn}
                    onChange={(e) => setNameBn(e.target.value)}
                    placeholder="বাসমতি চাল"
                    required
                  />
                </div>
              </div>

              {/* SKU, Category & Unit */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.sku} *</Label>
                  <Input
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">التصنيف</Label>
                  <Input
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="مواد غذائية / مشروبات"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">الوحدة (حبة / كيس / كرتون)</Label>
                  <Input
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="حبة"
                  />
                </div>
              </div>

              {/* Cost Price & Selling Price */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-700">
                    {t.costPrice} (التكلفة) *
                  </Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={costPrice}
                    onChange={(e) => setCostPrice(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold text-slate-700">
                    {t.sellingPrice} (سعر البيع) *
                  </Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Stock Quantity & Alert Range (من كذا لكذا) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">{t.stockQuantity} الحالي</Label>
                  <Input
                    type="number"
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">
                    الحد الأدنى للتنبيه (من)
                  </Label>
                  <Input
                    type="number"
                    value={minStockAlert}
                    onChange={(e) => setMinStockAlert(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-semibold">
                    الحد المستهدف (إلى)
                  </Label>
                  <Input
                    type="number"
                    value={maxStockAlert}
                    onChange={(e) => setMaxStockAlert(e.target.value)}
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={uploadingImage || createMutation.isPending || updateMutation.isPending}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold h-10 rounded-xl"
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                ) : (
                  t.saveChanges
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
