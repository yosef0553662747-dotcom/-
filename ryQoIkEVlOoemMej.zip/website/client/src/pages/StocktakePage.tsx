import React, { useState } from "react";
import HeaderNav from "../components/HeaderNav";
import { useLanguage } from "../contexts/LanguageContext";
import { trpc } from "../lib/trpc";
import {
  ClipboardCheck,
  Plus,
  Send,
  CheckCircle,
  AlertTriangle,
  Calendar,
  Save,
  Check,
  RotateCcw,
  Clock,
  Layers,
  ArrowRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function StocktakePage() {
  const { t, language } = useLanguage();
  const [selectedSessionId, setSelectedSessionId] = useState<number | null>(null);
  const [newDialogOpen, setNewDialogOpen] = useState(false);

  // New session state
  const [sessionTitle, setSessionTitle] = useState("جرد نهاية الأسبوع");
  const [cycleType, setCycleType] = useState<"daily" | "weekly" | "adhoc">("weekly");
  const [notes, setNotes] = useState("يرجى مراجعة وتدقيق أصناف الرفوف والمستودع بدقة");
  const [notifyWorkers, setNotifyWorkers] = useState(true);

  // Quick count editing map
  const [countInputs, setCountInputs] = useState<Record<number, string>>({});

  const sessionsQuery = trpc.stocktake.list.useQuery();
  const utils = trpc.useUtils();

  const detailsQuery = trpc.stocktake.getDetails.useQuery(
    { id: selectedSessionId! },
    { enabled: !!selectedSessionId }
  );

  const productsQuery = trpc.products.list.useQuery();

  const createSessionMutation = trpc.stocktake.createSession.useMutation({
    onSuccess: (data) => {
      toast.success(`تم إنشاء جلسة الجرد بنجاح كود: ${data.sessionCode} وإرسال إشعار للعمال!`);
      setNewDialogOpen(false);
      setSelectedSessionId(data.sessionId);
      utils.stocktake.list.invalidate();
      utils.notifications.list.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const submitCountMutation = trpc.stocktake.submitItemCount.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل الكمية الفعلية بنجاح");
      utils.stocktake.getDetails.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  const completeSessionMutation = trpc.stocktake.completeSession.useMutation({
    onSuccess: () => {
      toast.success("تم إنهاء الجرد واعتماد الكميات الفعلية وتحديث المخزون بنجاح!");
      utils.stocktake.getDetails.invalidate();
      utils.stocktake.list.invalidate();
      utils.products.list.invalidate();
      utils.reports.dashboardSummary.invalidate();
    },
    onError: (err) => toast.error(err.message || t.error),
  });

  // Set default selected session if none
  React.useEffect(() => {
    if (!selectedSessionId && sessionsQuery.data && sessionsQuery.data.length > 0) {
      setSelectedSessionId(sessionsQuery.data[0].id);
    }
  }, [sessionsQuery.data, selectedSessionId]);

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    createSessionMutation.mutate({
      title: sessionTitle.trim(),
      cycleType,
      notes,
      notifyStaff: notifyWorkers,
    });
  };

  const handleSaveCount = (itemId: number) => {
    const val = countInputs[itemId];
    if (val === undefined || val === "") {
      toast.error("يرجى إدخال العدد الفعلي");
      return;
    }
    const actualQuantity = parseInt(val, 10);
    if (isNaN(actualQuantity) || actualQuantity < 0) {
      toast.error("الكمية غير صحيحة");
      return;
    }
    submitCountMutation.mutate({
      itemId,
      actualQuantity,
    });
  };

  const productMap = React.useMemo(() => {
    const map = new Map();
    productsQuery.data?.forEach((p) => map.set(p.id, p));
    return map;
  }, [productsQuery.data]);

  const activeSession = detailsQuery.data?.session;
  const activeItems = detailsQuery.data?.items || [];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <HeaderNav portal="admin" />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <ClipboardCheck className="w-6 h-6 text-amber-500" />
              <span>{t.inventoryStocktake}</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              إدارة الجرد الدوري (يومي / أسبوعي)، إرسال تنبيهات للعمال لحصر البضاعة، وتحديث المخزون آلياً
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Dialog open={newDialogOpen} onOpenChange={setNewDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold gap-2 text-xs rounded-xl shadow-md shadow-amber-500/20">
                  <Plus className="w-4 h-4" />
                  {t.newStocktake}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md bg-white rounded-2xl">
                <DialogHeader>
                  <DialogTitle className="text-lg font-bold">
                    بدء جلسة جرد جديدة وإرسال إشعار للعمال
                  </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleCreateSession} className="space-y-4 pt-2">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">عنوان جلسة الجرد</Label>
                    <Input
                      value={sessionTitle}
                      onChange={(e) => setSessionTitle(e.target.value)}
                      placeholder="مثال: جرد نهاية الأسبوع الشامل"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">{t.cycleType}</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant={cycleType === "daily" ? "default" : "outline"}
                        onClick={() => setCycleType("daily")}
                        className="text-xs"
                      >
                        {t.daily}
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant={cycleType === "weekly" ? "default" : "outline"}
                        onClick={() => setCycleType("weekly")}
                        className="text-xs"
                      >
                        {t.weekly}
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant={cycleType === "adhoc" ? "default" : "outline"}
                        onClick={() => setCycleType("adhoc")}
                        className="text-xs"
                      >
                        {t.adhoc}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">ملاحظات وتوجيهات للعمال</Label>
                    <Input
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="تعليمات الجرد..."
                    />
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs flex items-center justify-between">
                    <span className="font-semibold text-amber-900">
                      إرسال إشعار فوري للعمال: "سوو جرد الآن"
                    </span>
                    <input
                      type="checkbox"
                      checked={notifyWorkers}
                      onChange={(e) => setNotifyWorkers(e.target.checked)}
                      className="w-4 h-4 text-amber-600 rounded"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={createSessionMutation.isPending}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold"
                  >
                    {createSessionMutation.isPending ? "جاري الإنشاء..." : "بدء الجرد الآن"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Sessions Horizontal Selector */}
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          {sessionsQuery.data?.map((s) => {
            const isSelected = selectedSessionId === s.id;
            return (
              <div
                key={s.id}
                onClick={() => setSelectedSessionId(s.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer min-w-[220px] shrink-0 ${
                  isSelected
                    ? "bg-white border-amber-500 shadow-md ring-2 ring-amber-500/20"
                    : "bg-white/70 border-slate-200 hover:bg-white"
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-mono text-slate-400 font-semibold">
                    {s.sessionCode}
                  </span>
                  <Badge
                    variant={s.status === "completed" ? "default" : "secondary"}
                    className={`text-[10px] ${
                      s.status === "completed"
                        ? "bg-emerald-600 text-white"
                        : "bg-amber-100 text-amber-800"
                    }`}
                  >
                    {s.status === "completed" ? "معتمد ومكتمل" : "جاري العد"}
                  </Badge>
                </div>
                <h3 className="font-bold text-slate-900 text-sm truncate">
                  {s.title}
                </h3>
                <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>دورة: {s.cycleType === "daily" ? "يومي" : s.cycleType === "weekly" ? "أسبوعي" : "فوري"}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Active Session Counting Table */}
        {activeSession && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-amber-500 text-slate-950 font-bold">
                    {activeSession.sessionCode}
                  </Badge>
                  <h2 className="text-lg font-bold text-slate-900">
                    {activeSession.title}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  تاريخ الجلسة: {new Date(activeSession.createdAt).toLocaleDateString()} | ملاحظات:{" "}
                  {activeSession.notes || "لا توجد"}
                </p>
              </div>

              {activeSession.status !== "completed" && (
                <Button
                  onClick={() => {
                    if (confirm("هل تريد اعتماد الكميات وتحديث المخزون الفعلي للنظام؟")) {
                      completeSessionMutation.mutate({
                        sessionId: activeSession.id,
                        applyToInventory: true,
                      });
                    }
                  }}
                  disabled={completeSessionMutation.isPending}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-2 rounded-xl shadow-md shadow-emerald-600/20"
                >
                  <CheckCircle className="w-4 h-4" />
                  {t.completeStocktake}
                </Button>
              )}
            </div>

            {/* Items Count Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-50 text-slate-600 border-b">
                  <tr>
                    <th className="py-2.5 px-3">المنتج</th>
                    <th className="py-2.5 px-3">المتوقع بالنظام</th>
                    <th className="py-2.5 px-3">العدد الفعلي بالجرد</th>
                    <th className="py-2.5 px-3">الفرق (عجز / زيادة)</th>
                    <th className="py-2.5 px-3">فارق التكلفة</th>
                    <th className="py-2.5 px-3">الإجراء</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeItems.map((item) => {
                    const prod = productMap.get(item.productId);
                    const prodName =
                      language === "bn"
                        ? prod?.nameBn
                        : language === "en"
                        ? prod?.nameEn
                        : prod?.nameAr;

                    const hasCount = item.actualQuantity !== null && item.actualQuantity !== undefined;
                    const diff = item.difference ?? 0;

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900">
                            {prodName || `منتج #${item.productId}`}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            SKU: {prod?.sku || "-"}
                          </div>
                        </td>

                        <td className="py-3 px-3 font-semibold text-slate-700">
                          {item.expectedQuantity} {prod?.unit || "حبة"}
                        </td>

                        <td className="py-3 px-3">
                          {activeSession.status === "completed" ? (
                            <span className="font-bold text-slate-900 text-sm">
                              {item.actualQuantity} {prod?.unit || "حبة"}
                            </span>
                          ) : (
                            <div className="flex items-center gap-1.5 w-32">
                              <Input
                                type="number"
                                min="0"
                                placeholder="العدد..."
                                value={
                                  countInputs[item.id] !== undefined
                                    ? countInputs[item.id]
                                    : hasCount
                                    ? String(item.actualQuantity)
                                    : ""
                                }
                                onChange={(e) =>
                                  setCountInputs((prev) => ({
                                    ...prev,
                                    [item.id]: e.target.value,
                                  }))
                                }
                                className="h-8 text-xs bg-slate-50 font-bold"
                              />
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3">
                          {hasCount ? (
                            <Badge
                              variant={diff === 0 ? "outline" : diff < 0 ? "destructive" : "default"}
                              className={`text-[11px] ${
                                diff === 0
                                  ? "border-emerald-600 text-emerald-700 bg-emerald-50"
                                  : diff > 0
                                  ? "bg-blue-600 text-white"
                                  : "bg-red-600 text-white"
                              }`}
                            >
                              {diff === 0 ? "مطابق تماماً" : diff > 0 ? `+${diff} زيادة` : `${diff} عجز`}
                            </Badge>
                          ) : (
                            <span className="text-slate-400 text-[11px]">في الانتظار</span>
                          )}
                        </td>

                        <td className="py-3 px-3 font-semibold text-slate-700">
                          {item.costDifference ? `${item.costDifference} ${t.currency}` : "-"}
                        </td>

                        <td className="py-3 px-3">
                          {activeSession.status !== "completed" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleSaveCount(item.id)}
                              className="text-xs h-7 px-2.5 gap-1 border-emerald-600 text-emerald-700 hover:bg-emerald-50"
                            >
                              <Save className="w-3 h-3" />
                              حفظ العد
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
