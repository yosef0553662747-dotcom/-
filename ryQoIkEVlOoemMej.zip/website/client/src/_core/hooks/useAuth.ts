import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect } from "react";

type UseAuthOptions = { redirectOnUnauthenticated?: boolean; redirectPath?: string };
export function useAuth(options?: UseAuthOptions) {
  const {redirectOnUnauthenticated=false, redirectPath} = options ?? {}; const utils=trpc.useUtils();
  const meQuery=trpc.auth.me.useQuery(undefined,{retry:false,refetchOnWindowFocus:false});
  const logoutMutation=trpc.auth.logout.useMutation({onSuccess:()=>utils.auth.me.setData(undefined,null)});
  const logout=useCallback(async()=>{try{await logoutMutation.mutateAsync()}catch(e){if(!(e instanceof TRPCClientError && e.data?.code==="UNAUTHORIZED")) throw e}finally{utils.auth.me.setData(undefined,null); await utils.auth.me.invalidate()}},[logoutMutation,utils]);
  const user=meQuery.data ?? null; const loading=meQuery.isLoading || logoutMutation.isPending;
  useEffect(()=>{if(redirectOnUnauthenticated&&!loading&&!user&&typeof window!=="undefined"&&window.location.pathname!==(redirectPath||"/login")) window.location.href=redirectPath||"/login"},[redirectOnUnauthenticated,redirectPath,loading,user]);
  return {user,loading,error:meQuery.error??logoutMutation.error??null,isAuthenticated:Boolean(user),refresh:()=>meQuery.refetch(),logout};
}
