import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import LoginPage from "./pages/LoginPage";
import PosPage from "./pages/PosPage";
import DashboardPage from "./pages/DashboardPage";
import ProductsPage from "./pages/ProductsPage";
import StocktakePage from "./pages/StocktakePage";
import SalesHistoryPage from "./pages/SalesHistoryPage";
import StaffPage from "./pages/StaffPage";
import MenuPage from "./pages/MenuPage";
import DeveloperSettingsPage from "./pages/DeveloperSettingsPage";
import { useAuth } from "./_core/hooks/useAuth";

function RoleRoute({
  component: Component,
  requiredRole,
}: {
  component: React.ComponentType<any>;
  requiredRole: "admin" | "worker" | "developer";
}) {
  const { user, loading } = useAuth();
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" /></div>;
  }
  if (!user) return <Redirect to="/login" />;
  const role = (user as any)?.staff?.role || (user as any)?.role || "worker";
  if (role !== requiredRole) return <Redirect to={role === "admin" ? "/admin" : role === "developer" ? "/developer" : "/workers"} />;
  return <Component />;
}

function Router() {
  const { user, loading } = useAuth();
  return (
    <Switch>
      <Route path="/">
        {loading ? <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" /></div> : user ? ((user as any)?.staff?.role === "admin" || (user as any)?.role === "admin" ? <Redirect to="/admin" /> : (user as any)?.staff?.role === "developer" ? <Redirect to="/developer" /> : <Redirect to="/workers" />) : <Redirect to="/login" />}
      </Route>
      <Route path="/login" component={LoginPage} />
      <Route path="/workers"><RoleRoute component={PosPage} requiredRole="worker" /></Route>
      <Route path="/menu"><RoleRoute component={MenuPage} requiredRole="worker" /></Route>
      <Route path="/admin"><RoleRoute component={DashboardPage} requiredRole="admin" /></Route>
      <Route path="/admin/menu"><RoleRoute component={() => <MenuPage portal="admin" />} requiredRole="admin" /></Route>
      <Route path="/developer"><RoleRoute component={DeveloperSettingsPage} requiredRole="developer" /></Route>
      {/* Backward-compatible aliases now point to the separated portals. */}
      <Route path="/pos"><Redirect to="/workers" /></Route>
      <Route path="/dashboard"><Redirect to="/admin" /></Route>
      <Route path="/products"><RoleRoute component={ProductsPage} requiredRole="admin" /></Route>
      <Route path="/stocktake"><RoleRoute component={StocktakePage} requiredRole="admin" /></Route>
      <Route path="/sales"><RoleRoute component={SalesHistoryPage} requiredRole="admin" /></Route>
      <Route path="/staff"><RoleRoute component={StaffPage} requiredRole="admin" /></Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <ThemeProvider defaultTheme="light">
          <TooltipProvider><Toaster position="top-center" richColors /><Router /></TooltipProvider>
        </ThemeProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}

export default App;
