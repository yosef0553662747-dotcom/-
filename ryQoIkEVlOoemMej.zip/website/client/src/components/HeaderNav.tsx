import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../_core/hooks/useAuth";
import { trpc } from "../lib/trpc";
import {
  Bell,
  Globe,
  LogOut,
  ShieldAlert,
  Store,
  BarChart3,
  Boxes,
  ClipboardList,
  Receipt,
  Users,
  Utensils,
  Code2,
  Menu,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

type Portal = "worker" | "admin" | "developer";

export default function HeaderNav({ portal }: { portal: Portal }) {
  const { language, setLanguage, t, dir } = useLanguage();
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const isAdmin = portal === "admin";
  const isDeveloper = portal === "developer";
  const anyUser = user as any;
  const staff = anyUser?.staff;

  const notificationsQuery = trpc.notifications.list.useQuery(undefined, {
    enabled: isAdmin,
    refetchInterval: isAdmin ? 10000 : false,
  });
  const brandingQuery = trpc.settings.public.useQuery();
  const unreadCount = notificationsQuery.data?.filter((n) => !n.isRead)?.length || 0;
  const displayName = staff?.fullName || anyUser?.user?.name || anyUser?.name || "مستخدم";
  const branding = brandingQuery.data || {};
  const appName = language === "en" ? branding.appNameEn || t.appName : language === "bn" ? branding.appNameBn || t.appName : branding.appNameAr || t.appName;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div
            className="flex items-center gap-3 cursor-pointer min-w-0 max-w-[62%] lg:max-w-none"
            onClick={() => setLocation(isAdmin ? "/admin" : isDeveloper ? "/developer" : "/workers")}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 overflow-hidden">
              {branding.logoUrl ? <img src={branding.logoUrl} alt="logo" className="w-full h-full object-cover" /> : <Store className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 truncate">{appName}</span>
                <Badge variant={isAdmin ? "default" : "secondary"} className="text-xs px-2 py-0.5 rounded-full">
                  {isAdmin ? t.admin : isDeveloper ? "المطور" : t.worker}
                </Badge>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                {isAdmin ? t.portalTitleAdmin : isDeveloper ? "تخصيص البرنامج وإعداداته" : "واجهة الطلبات والكاشير للعمال"}
              </p>
            </div>
          </div>

          <nav className="hidden lg:flex flex-1 min-w-0 items-center justify-center gap-1 overflow-x-auto px-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {isAdmin ? (
              <>
                <Button variant={location === "/admin" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/admin")} className="gap-2 font-medium">
                  <BarChart3 className="w-4 h-4 text-emerald-600" />{t.dashboard}
                </Button>
                <Button variant={location === "/products" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/products")} className="gap-2 font-medium">
                  <Boxes className="w-4 h-4 text-indigo-600" />{t.productsAndStock}
                </Button>
                <Button variant={location === "/admin/menu" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/admin/menu")} className="gap-2 font-medium">
                  <Utensils className="w-4 h-4 text-orange-600" />المنيو
                </Button>
                <Button variant={location === "/stocktake" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/stocktake")} className="gap-2 font-medium">
                  <ClipboardList className="w-4 h-4 text-amber-600" />{t.inventoryStocktake}
                </Button>
                <Button variant={location === "/sales" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/sales")} className="gap-2 font-medium">
                  <Receipt className="w-4 h-4 text-blue-600" />{t.ordersAndSales}
                </Button>
                <Button variant={location === "/staff" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/staff")} className="gap-2 font-medium">
                  <Users className="w-4 h-4 text-purple-600" />{t.staffManagement}
                </Button>
              </>
            ) : isDeveloper ? (
              <Button variant="secondary" size="sm" onClick={() => setLocation("/developer")} className="gap-2 font-medium"><Code2 className="w-4 h-4 text-violet-600" /> إعدادات المطور</Button>
            ) : (
              <>
                <Button variant={location === "/workers" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/workers")} className="gap-2 font-medium"><Receipt className="w-4 h-4 text-teal-600" />طلبات البيع والكاشير</Button>
                <Button variant={location === "/menu" ? "secondary" : "ghost"} size="sm" onClick={() => setLocation("/menu")} className="gap-2 font-medium"><Utensils className="w-4 h-4 text-orange-600" />المنيو</Button>
              </>
            )}
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden rounded-lg" aria-label="فتح القائمة">
                  <Menu className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={dir === "rtl" ? "start" : "end"} className="w-56">
                {isAdmin ? <>
                  <DropdownMenuItem onClick={() => setLocation("/admin")}>لوحة الإدارة</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/products")}>المنتجات والمخزون</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/admin/menu")}>المنيو</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/stocktake")}>الجرد</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/sales")}>الطلبات والمبيعات</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/staff")}>العمال</DropdownMenuItem>
                </> : isDeveloper ? <DropdownMenuItem onClick={() => setLocation("/developer")}>إعدادات المطور</DropdownMenuItem> : <>
                  <DropdownMenuItem onClick={() => setLocation("/workers")}>طلبات البيع والكاشير</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/menu")}>المنيو</DropdownMenuItem>
                </>}
              </DropdownMenuContent>
            </DropdownMenu>
            {isAdmin && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" className="relative rounded-full">
                    <Bell className="w-4 h-4 text-slate-700" />
                    {unreadCount > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-bold">{unreadCount}</span>}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align={dir === "rtl" ? "start" : "end"} className="w-80 p-2 max-h-96 overflow-y-auto">
                  <div className="flex items-center justify-between pb-2 border-b px-2 font-semibold text-sm"><span>{t.notifications}</span><span className="text-xs text-muted-foreground">{unreadCount}</span></div>
                  {notificationsQuery.data?.map((notif) => {
                    const title = language === "bn" ? notif.titleBn : language === "en" ? notif.titleEn : notif.titleAr;
                    const msg = language === "bn" ? notif.messageBn : language === "en" ? notif.messageEn : notif.messageAr;
                    return <div key={notif.id} className="p-2.5 my-1 rounded-lg text-xs bg-slate-50 border border-slate-200"><div className="font-bold text-slate-900 mb-1 flex items-center gap-1.5"><ShieldAlert className="w-3.5 h-3.5 text-amber-600" />{title}</div><p className="text-slate-600 leading-relaxed">{msg}</p></div>;
                  })}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5 rounded-lg px-2.5"><Globe className="w-4 h-4 text-emerald-600" /><span className="text-xs font-semibold">{language === "ar" ? "العربية" : language === "en" ? "EN" : "বাংলা"}</span></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={dir === "rtl" ? "start" : "end"}>
                <DropdownMenuItem onClick={() => setLanguage("ar")}>العربية</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage("en")}>English</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage("bn")}>বাংলা</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2 px-2"><div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-300 flex items-center justify-center font-bold text-slate-700 text-xs">{displayName.charAt(0)}</div><div className="hidden lg:flex flex-col text-right"><span className="text-xs font-bold leading-none text-slate-800 truncate max-w-[120px]">{displayName}</span><span className="text-[10px] text-slate-500 leading-none mt-1">{isAdmin ? t.admin : t.worker}</span></div></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={dir === "rtl" ? "start" : "end"} className="w-48"><DropdownMenuItem onClick={logout} className="text-red-600 focus:text-red-600 cursor-pointer"><LogOut className="w-4 h-4 mr-2" /><span>{t.logout}</span></DropdownMenuItem></DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
