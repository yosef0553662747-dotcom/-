import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const staffAccounts = mysqlTable("staff_accounts", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  fullName: varchar("fullName", { length: 120 }).notNull(),
  role: mysqlEnum("role", ["admin", "worker", "developer"]).default("worker").notNull(),
  preferredLanguage: mysqlEnum("preferredLanguage", ["ar", "en", "bn"]).default("ar").notNull(),
  phone: varchar("phone", { length: 32 }),
  isActive: int("isActive").default(1).notNull(),
  lastLoginAt: timestamp("lastLoginAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StaffAccount = typeof staffAccounts.$inferSelect;
export type InsertStaffAccount = typeof staffAccounts.$inferInsert;

export const appSettings = mysqlTable("app_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
  settingValue: text("settingValue"),
  updatedByStaffId: int("updatedByStaffId"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = typeof appSettings.$inferInsert;

export const menuSections = mysqlTable("menu_sections", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  nameAr: varchar("nameAr", { length: 120 }).notNull(),
  nameEn: varchar("nameEn", { length: 120 }).notNull(),
  nameBn: varchar("nameBn", { length: 120 }).notNull(),
  imageUrl: text("imageUrl"),
  displayOrder: int("displayOrder").notNull().default(0),
  isActive: int("isActive").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MenuSection = typeof menuSections.$inferSelect;
export type InsertMenuSection = typeof menuSections.$inferInsert;

export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  sku: varchar("sku", { length: 64 }).notNull().unique(),
  barcode: varchar("barcode", { length: 64 }),
  nameAr: varchar("nameAr", { length: 255 }).notNull(),
  nameEn: varchar("nameEn", { length: 255 }).notNull(),
  nameBn: varchar("nameBn", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).default("general").notNull(),
  imageUrl: text("imageUrl"),
  costPrice: decimal("costPrice", { precision: 10, scale: 2 }).notNull().default("0.00"),
  sellingPrice: decimal("sellingPrice", { precision: 10, scale: 2 }).notNull().default("0.00"),
  taxRate: decimal("taxRate", { precision: 5, scale: 2 }).notNull().default("15.00"), // 15% VAT default
  stockQuantity: int("stockQuantity").notNull().default(0),
  minStockAlert: int("minStockAlert").notNull().default(5),
  maxStockAlert: int("maxStockAlert").notNull().default(50),
  unit: varchar("unit", { length: 32 }).default("pcs").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

export const salesOrders = mysqlTable("sales_orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNumber: varchar("orderNumber", { length: 64 }).notNull().unique(),
  customerNumber: int("customerNumber").notNull(), // e.g. Customer #55
  customerName: varchar("customerName", { length: 120 }),
  customerPhone: varchar("customerPhone", { length: 32 }),
  sellerStaffId: int("sellerStaffId").notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  totalTax: decimal("totalTax", { precision: 10, scale: 2 }).notNull(),
  totalCost: decimal("totalCost", { precision: 10, scale: 2 }).notNull(),
  grandTotal: decimal("grandTotal", { precision: 10, scale: 2 }).notNull(),
  netProfit: decimal("netProfit", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "card", "online", "credit"]).default("cash").notNull(),
  status: mysqlEnum("status", ["completed", "cancelled", "refunded"]).default("completed").notNull(),
  cancelReason: text("cancelReason"),
  cancelledByStaffId: int("cancelledByStaffId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SalesOrder = typeof salesOrders.$inferSelect;
export type InsertSalesOrder = typeof salesOrders.$inferInsert;

export const salesOrderItems = mysqlTable("sales_order_items", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  productId: int("productId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  quantity: int("quantity").notNull(),
  unitCostPrice: decimal("unitCostPrice", { precision: 10, scale: 2 }).notNull(),
  unitSellingPrice: decimal("unitSellingPrice", { precision: 10, scale: 2 }).notNull(),
  taxRate: decimal("taxRate", { precision: 5, scale: 2 }).notNull(),
  taxAmount: decimal("taxAmount", { precision: 10, scale: 2 }).notNull(),
  lineTotal: decimal("lineTotal", { precision: 10, scale: 2 }).notNull(),
  lineProfit: decimal("lineProfit", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SalesOrderItem = typeof salesOrderItems.$inferSelect;
export type InsertSalesOrderItem = typeof salesOrderItems.$inferInsert;

export const stocktakeSessions = mysqlTable("stocktake_sessions", {
  id: int("id").autoincrement().primaryKey(),
  sessionCode: varchar("sessionCode", { length: 64 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  cycleType: mysqlEnum("cycleType", ["daily", "weekly", "adhoc"]).default("daily").notNull(),
  status: mysqlEnum("status", ["requested", "in_progress", "completed", "cancelled"]).default("requested").notNull(),
  requestedByStaffId: int("requestedByStaffId").notNull(),
  assignedToStaffId: int("assignedToStaffId"), // NULL = all workers
  notes: text("notes"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StocktakeSession = typeof stocktakeSessions.$inferSelect;
export type InsertStocktakeSession = typeof stocktakeSessions.$inferInsert;

export const stocktakeItems = mysqlTable("stocktake_items", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  productId: int("productId").notNull(),
  expectedQuantity: int("expectedQuantity").notNull(),
  actualQuantity: int("actualQuantity"),
  difference: int("difference"),
  costDifference: decimal("costDifference", { precision: 10, scale: 2 }).default("0.00"),
  countedByStaffId: int("countedByStaffId"),
  remarks: text("remarks"),
  countedAt: timestamp("countedAt"),
});

export type StocktakeItem = typeof stocktakeItems.$inferSelect;
export type InsertStocktakeItem = typeof stocktakeItems.$inferInsert;

export const staffNotifications = mysqlTable("staff_notifications", {
  id: int("id").autoincrement().primaryKey(),
  senderStaffId: int("senderStaffId").notNull(),
  targetStaffId: int("targetStaffId"), // NULL means broadcast to all staff
  titleAr: varchar("titleAr", { length: 255 }).notNull(),
  titleEn: varchar("titleEn", { length: 255 }).notNull(),
  titleBn: varchar("titleBn", { length: 255 }).notNull(),
  messageAr: text("messageAr").notNull(),
  messageEn: text("messageEn").notNull(),
  messageBn: text("messageBn").notNull(),
  type: mysqlEnum("type", ["stocktake_alert", "low_stock", "announcement", "general"]).default("general").notNull(),
  referenceId: varchar("referenceId", { length: 64 }),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StaffNotification = typeof staffNotifications.$inferSelect;
export type InsertStaffNotification = typeof staffNotifications.$inferInsert;
