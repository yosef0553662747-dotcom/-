CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sku` varchar(64) NOT NULL,
	`barcode` varchar(64),
	`nameAr` varchar(255) NOT NULL,
	`nameEn` varchar(255) NOT NULL,
	`nameBn` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL DEFAULT 'general',
	`imageUrl` text,
	`costPrice` decimal(10,2) NOT NULL DEFAULT '0.00',
	`sellingPrice` decimal(10,2) NOT NULL DEFAULT '0.00',
	`taxRate` decimal(5,2) NOT NULL DEFAULT '15.00',
	`stockQuantity` int NOT NULL DEFAULT 0,
	`minStockAlert` int NOT NULL DEFAULT 5,
	`maxStockAlert` int NOT NULL DEFAULT 50,
	`unit` varchar(32) NOT NULL DEFAULT 'pcs',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_sku_unique` UNIQUE(`sku`)
);
--> statement-breakpoint
CREATE TABLE `sales_order_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`productId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`quantity` int NOT NULL,
	`unitCostPrice` decimal(10,2) NOT NULL,
	`unitSellingPrice` decimal(10,2) NOT NULL,
	`taxRate` decimal(5,2) NOT NULL,
	`taxAmount` decimal(10,2) NOT NULL,
	`lineTotal` decimal(10,2) NOT NULL,
	`lineProfit` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sales_order_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderNumber` varchar(64) NOT NULL,
	`customerNumber` int NOT NULL,
	`customerName` varchar(120),
	`customerPhone` varchar(32),
	`sellerStaffId` int NOT NULL,
	`subtotal` decimal(10,2) NOT NULL,
	`totalTax` decimal(10,2) NOT NULL,
	`totalCost` decimal(10,2) NOT NULL,
	`grandTotal` decimal(10,2) NOT NULL,
	`netProfit` decimal(10,2) NOT NULL,
	`paymentMethod` enum('cash','card','online','credit') NOT NULL DEFAULT 'cash',
	`status` enum('completed','cancelled','refunded') NOT NULL DEFAULT 'completed',
	`cancelReason` text,
	`cancelledByStaffId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sales_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `sales_orders_orderNumber_unique` UNIQUE(`orderNumber`)
);
--> statement-breakpoint
CREATE TABLE `staff_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(64) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`fullName` varchar(120) NOT NULL,
	`role` enum('admin','worker') NOT NULL DEFAULT 'worker',
	`preferredLanguage` enum('ar','en','bn') NOT NULL DEFAULT 'ar',
	`phone` varchar(32),
	`isActive` int NOT NULL DEFAULT 1,
	`lastLoginAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `staff_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `staff_accounts_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `staff_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`senderStaffId` int NOT NULL,
	`targetStaffId` int,
	`titleAr` varchar(255) NOT NULL,
	`titleEn` varchar(255) NOT NULL,
	`titleBn` varchar(255) NOT NULL,
	`messageAr` text NOT NULL,
	`messageEn` text NOT NULL,
	`messageBn` text NOT NULL,
	`type` enum('stocktake_alert','low_stock','announcement','general') NOT NULL DEFAULT 'general',
	`referenceId` varchar(64),
	`isRead` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `staff_notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stocktake_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`productId` int NOT NULL,
	`expectedQuantity` int NOT NULL,
	`actualQuantity` int,
	`difference` int,
	`costDifference` decimal(10,2) DEFAULT '0.00',
	`countedByStaffId` int,
	`remarks` text,
	`countedAt` timestamp,
	CONSTRAINT `stocktake_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stocktake_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionCode` varchar(64) NOT NULL,
	`title` varchar(255) NOT NULL,
	`cycleType` enum('daily','weekly','adhoc') NOT NULL DEFAULT 'daily',
	`status` enum('requested','in_progress','completed','cancelled') NOT NULL DEFAULT 'requested',
	`requestedByStaffId` int NOT NULL,
	`assignedToStaffId` int,
	`notes` text,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stocktake_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `stocktake_sessions_sessionCode_unique` UNIQUE(`sessionCode`)
);
