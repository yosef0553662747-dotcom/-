CREATE TABLE `menu_sections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(80) NOT NULL,
	`nameAr` varchar(120) NOT NULL,
	`nameEn` varchar(120) NOT NULL,
	`nameBn` varchar(120) NOT NULL,
	`imageUrl` text,
	`displayOrder` int NOT NULL DEFAULT 0,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `menu_sections_id` PRIMARY KEY(`id`),
	CONSTRAINT `menu_sections_slug_unique` UNIQUE(`slug`)
);
